Trix AI Android project
Build with GitHub Actions using the included workflow.
Project folder inside this archive: TrixAI/
Required: JDK 17, Gradle 8.2, Android SDK 35.
