package com.trixai.assistant.util

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "trix_ai_prefs")

class PreferenceManager(private val context: Context) {

    companion object {
        val KEY_ONBOARDING_COMPLETE = booleanPreferencesKey("onboarding_complete")
        val KEY_VOICE_LANGUAGE = stringPreferencesKey("voice_language")
        val KEY_WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val KEY_OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
        val KEY_HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")
        val KEY_SPEECH_FEEDBACK = booleanPreferencesKey("speech_feedback")
        val KEY_CONFIRMATION_LEVEL = stringPreferencesKey("confirmation_level")
        val KEY_TEXT_SIZE = stringPreferencesKey("text_size")
        val KEY_BUTTON_SIZE = stringPreferencesKey("button_size")
        val KEY_VOICE_SPEED = floatPreferencesKey("voice_speed")
        val KEY_BACKGROUND_SERVICE = booleanPreferencesKey("background_service")
        val KEY_POWER_BUTTON_WAKE = booleanPreferencesKey("power_button_wake")
        val KEY_ACCESSIBILITY_GRANTED = booleanPreferencesKey("accessibility_granted")
        val KEY_NOTIFICATION_ACCESS = booleanPreferencesKey("notification_access")
        val KEY_CAMERA_PERMISSION = booleanPreferencesKey("camera_permission")
        val KEY_CONTACT_PERMISSION = booleanPreferencesKey("contact_permission")
        val KEY_SMS_PERMISSION = booleanPreferencesKey("sms_permission")
        val KEY_LOCATION_PERMISSION = booleanPreferencesKey("location_permission")
        val KEY_PHONE_PERMISSION = booleanPreferencesKey("phone_permission")
        val KEY_MICROPHONE_PERMISSION = booleanPreferencesKey("microphone_permission")
        val KEY_LAST_ACTION_ID = stringPreferencesKey("last_action_id")
        val KEY_LAST_ACTION_TIME = longPreferencesKey("last_action_time")
    }

    val voiceLanguage: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_VOICE_LANGUAGE] ?: "auto"
    }

    val wakeWordEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_WAKE_WORD_ENABLED] ?: false
    }

    val overlayEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_OVERLAY_ENABLED] ?: false
    }

    val hapticEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_HAPTIC_ENABLED] ?: true
    }

    val speechFeedbackEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_SPEECH_FEEDBACK] ?: true
    }

    val backgroundServiceEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_BACKGROUND_SERVICE] ?: true
    }

    val onboardingComplete: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_ONBOARDING_COMPLETE] ?: false
    }

    suspend fun setOnboardingComplete(complete: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_ONBOARDING_COMPLETE] = complete
        }
    }

    suspend fun setVoiceLanguage(language: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_VOICE_LANGUAGE] = language
        }
    }

    suspend fun setWakeWordEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_WAKE_WORD_ENABLED] = enabled
        }
    }

    suspend fun setOverlayEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_OVERLAY_ENABLED] = enabled
        }
    }

    suspend fun setHapticEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_HAPTIC_ENABLED] = enabled
        }
    }

    suspend fun setSpeechFeedback(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_SPEECH_FEEDBACK] = enabled
        }
    }

    suspend fun setBackgroundService(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_BACKGROUND_SERVICE] = enabled
        }
    }

    suspend fun setConfirmationLevel(level: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CONFIRMATION_LEVEL] = level
        }
    }

    suspend fun setTextSize(size: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_TEXT_SIZE] = size
        }
    }

    suspend fun setButtonSize(size: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_BUTTON_SIZE] = size
        }
    }

    suspend fun setVoiceSpeed(speed: Float) {
        context.dataStore.edit { prefs ->
            prefs[KEY_VOICE_SPEED] = speed
        }
    }

    suspend fun setAccessibilityGranted(granted: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_ACCESSIBILITY_GRANTED] = granted
        }
    }

    suspend fun setLastAction(actionId: String, timestamp: Long) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LAST_ACTION_ID] = actionId
            prefs[KEY_LAST_ACTION_TIME] = timestamp
        }
    }

    suspend fun getLastAction(): Pair<String?, Long?> {
        val prefs = context.dataStore.data.first()
        return Pair(prefs[KEY_LAST_ACTION_ID], prefs[KEY_LAST_ACTION_TIME])
    }
}
