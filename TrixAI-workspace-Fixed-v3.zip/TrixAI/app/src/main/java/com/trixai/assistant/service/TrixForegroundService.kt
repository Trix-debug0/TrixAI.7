package com.trixai.assistant.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.trixai.assistant.R
import com.trixai.assistant.TrixAIApplication
import com.trixai.assistant.ui.main.MainActivity

class TrixForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, createNotification())
            }
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun createNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, TrixForegroundService::class.java).apply {
                action = ACTION_STOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, TrixAIApplication.CHANNEL_FOREGROUND)
            .setContentTitle("Trix AI")
            .setContentText("Trix AI is active")
            .setSmallIcon(R.drawable.ic_mic_white)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_mic_white, "Open Trix AI", openIntent)
            .addAction(R.drawable.ic_mic_white, "Stop Assistant", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        const val ACTION_START = "com.trixai.assistant.action.START"
        const val ACTION_STOP = "com.trixai.assistant.action.STOP"
        const val NOTIFICATION_ID = 1001
    }
}
