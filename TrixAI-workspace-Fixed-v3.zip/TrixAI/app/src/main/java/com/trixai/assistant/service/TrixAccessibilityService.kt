package com.trixai.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TrixAccessibilityService : AccessibilityService() {

    private val TAG = "TrixAccessibilityService"
    private var rootNode: AccessibilityNodeInfo? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                rootNode = rootInActiveWindow
                val className = event.className?.toString() ?: return
                Log.d(TAG, "Window changed: $className")
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                rootNode = rootInActiveWindow
            }
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                val text = event.text?.joinToString(" ") ?: ""
                Log.d(TAG, "Notification: $text")
                notificationListener?.invoke(text)
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.i(TAG, "Accessibility service destroyed")
    }

    fun getCurrentScreenElements(): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val elements = mutableListOf<String>()
        collectTextElements(root, elements)
        return elements.distinct()
    }

    fun clickElementByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        if (nodes.isNotEmpty()) {
            for (node in nodes) {
                if (node.isClickable) {
                    return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                // Try parent
                var parent = node.parent
                while (parent != null) {
                    if (parent.isClickable) {
                        return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    parent = parent.parent
                }
            }
        }
        return false
    }

    fun typeText(text: String) {
        val root = rootInActiveWindow ?: return
        val focusedNode = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focusedNode != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val arguments = android.os.Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
                focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            }
        }
    }

    fun scroll(direction: Int) {
        val root = rootInActiveWindow ?: return
        val scrollable = findScrollable(root)
        if (scrollable != null) {
            val action = if (direction > 0) {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            }
            scrollable.performAction(action)
        }
    }

    fun performGlobalBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun performGlobalHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun performGlobalRecents() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    fun performGlobalNotifications() {
        performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    fun clickMediaButton(action: String) {
        // Send media button event
        when (action) {
            "play", "pause" -> {
                val root = rootInActiveWindow ?: return
                // Try to find play/pause button
                val nodes = root.findAccessibilityNodeInfosByText("Play")
                    .ifEmpty { root.findAccessibilityNodeInfosByText("Pause") }
                    .ifEmpty { root.findAccessibilityNodeInfosByText("Resume") }
                for (node in nodes) {
                    if (node.isClickable) {
                        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        return
                    }
                }
            }
            "next" -> {
                val root = rootInActiveWindow ?: return
                val nodes = root.findAccessibilityNodeInfosByText("Next")
                for (node in nodes) {
                    if (node.isClickable) {
                        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        return
                    }
                }
            }
        }
    }

    private fun collectTextElements(node: AccessibilityNodeInfo, elements: MutableList<String>, depth: Int = 0) {
        if (depth > 20) return
        val text = node.text?.toString()?.trim()
        val contentDesc = node.contentDescription?.toString()?.trim()
        val element = text ?: contentDesc
        if (!element.isNullOrBlank() && element.length > 1) {
            elements.add(element)
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectTextElements(it, elements, depth + 1) }
        }
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findScrollable(child)
            if (result != null) return result
        }
        return null
    }

    companion object {
        var instance: TrixAccessibilityService? = null
            private set
        var notificationListener: ((String) -> Unit)? = null
    }
}
