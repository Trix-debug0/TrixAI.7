package com.trixai.assistant.device

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs

class DeviceInfo(private val context: Context) {

    fun getBatteryLevel(): Int {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) (level * 100 / scale) else -1
    }

    fun isCharging(): Boolean {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
    }

    fun getStorageInfo(): StorageInfo {
        val stat = StatFs(Environment.getExternalStorageDirectory().path)
        val totalBytes = stat.totalBytes
        val availBytes = stat.availableBytes
        return StorageInfo(
            totalGB = totalBytes / (1024.0 * 1024.0 * 1024.0),
            availableGB = availBytes / (1024.0 * 1024.0 * 1024.0),
            usedGB = (totalBytes - availBytes) / (1024.0 * 1024.0 * 1024.0)
        )
    }

    fun getAndroidVersion(): String = Build.VERSION.RELEASE
    fun getDeviceModel(): String = "${Build.MANUFACTURER} ${Build.MODEL}"
    fun getDeviceName(): String = Build.MODEL

    data class StorageInfo(
        val totalGB: Double,
        val availableGB: Double,
        val usedGB: Double
    )
}
