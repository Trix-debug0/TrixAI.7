package com.trixai.assistant.notification

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class TrixNotificationListener : NotificationListenerService() {

    private val TAG = "TrixNotificationListener"

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        Log.i(TAG, "Notification listener connected")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
        Log.i(TAG, "Notification listener disconnected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val packageName = sbn.packageName
        val notification = sbn.notification
        val extras = notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        Log.d(TAG, "Notification from $packageName: $title - $text")

        notificationCallback?.invoke(NotificationData(
            packageName = packageName,
            title = title,
            text = text,
            timestamp = sbn.postTime
        ))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // Handle removed notifications if needed
    }

    fun getActiveNotifications(): List<NotificationData> {
        return activeNotifications?.mapNotNull { sbn ->
            val extras = sbn.notification.extras
            val title = extras.getCharSequence("android.title")?.toString() ?: ""
            val text = extras.getCharSequence("android.text")?.toString() ?: ""
            if (title.isNotBlank() || text.isNotBlank()) {
                NotificationData(
                    packageName = sbn.packageName,
                    title = title,
                    text = text,
                    timestamp = sbn.postTime
                )
            } else null
        } ?: emptyList()
    }

    fun getNotificationsByPackage(packageName: String): List<NotificationData> {
        return getActiveNotifications().filter { it.packageName.contains(packageName) }
    }

    data class NotificationData(
        val packageName: String,
        val title: String,
        val text: String,
        val timestamp: Long
    )

    companion object {
        var instance: TrixNotificationListener? = null
            private set
        var notificationCallback: ((NotificationData) -> Unit)? = null
    }
}
