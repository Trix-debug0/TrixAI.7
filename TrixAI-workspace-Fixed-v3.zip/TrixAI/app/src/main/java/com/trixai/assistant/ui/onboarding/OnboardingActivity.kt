package com.trixai.assistant.ui.onboarding

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.trixai.assistant.R
import com.trixai.assistant.TrixAIApplication
import com.trixai.assistant.ui.main.MainActivity
import com.trixai.assistant.voice.VoiceManager
import com.trixai.assistant.util.PreferenceManager
import kotlinx.coroutines.launch

class OnboardingActivity : AppCompatActivity() {

    private lateinit var onboardingTitle: TextView
    private lateinit var onboardingDescription: TextView
    private lateinit var onboardingIcon: ImageView
    private lateinit var nextButton: Button
    private lateinit var skipButton: Button
    private lateinit var pageIndicator: TextView

    private var currentStep = 0
    private lateinit var voiceManager: VoiceManager
    private lateinit var prefManager: PreferenceManager

    private val steps = listOf(
        OnboardingStep(
            title = "Welcome to Trix AI",
            description = "Your voice can control your phone. Let me guide you through the setup.",
            icon = R.drawable.ic_mic_white
        ),
        OnboardingStep(
            title = "Microphone Permission",
            description = "I need microphone permission so I can hear your voice commands.",
            icon = R.drawable.ic_mic_white
        ),
        OnboardingStep(
            title = "Accessibility Access",
            description = "Accessibility access allows me to interact with your phone controls, read screens, and perform actions.",
            icon = R.drawable.ic_accessibility
        ),
        OnboardingStep(
            title = "Display Overlay",
            description = "Display overlay allows you to access Trix AI from other applications through a floating button.",
            icon = R.drawable.ic_overlay
        ),
        OnboardingStep(
            title = "Contacts & Phone",
            description = "I need contact and phone permission to make calls and send messages for you.",
            icon = R.drawable.ic_phone
        ),
        OnboardingStep(
            title = "Notifications",
            description = "Notification access allows me to read your notifications when you ask.",
            icon = R.drawable.ic_notification
        ),
        OnboardingStep(
            title = "You're All Set!",
            description = "Trix AI is ready. You can say 'Hey Trix' or tap the microphone button to start.",
            icon = R.drawable.ic_check
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        prefManager = (application as TrixAIApplication).preferenceManager
        voiceManager = VoiceManager(this, prefManager)

        initViews()
        setupListeners()
        updateStep()
    }

    private fun initViews() {
        onboardingTitle = findViewById(R.id.onboardingTitle)
        onboardingDescription = findViewById(R.id.onboardingDescription)
        onboardingIcon = findViewById(R.id.onboardingIcon)
        nextButton = findViewById(R.id.nextButton)
        skipButton = findViewById(R.id.skipButton)
        pageIndicator = findViewById(R.id.pageIndicator)
    }

    private fun setupListeners() {
        nextButton.setOnClickListener {
            handleStep()
        }

        skipButton.setOnClickListener {
            completeOnboarding()
        }
    }

    private fun handleStep() {
        when (currentStep) {
            0 -> { // Welcome
                voiceManager.speak("Let's get started with the setup.")
                moveToNext()
            }
            1 -> { // Microphone
                requestMicrophonePermission()
            }
            2 -> { // Accessibility
                openAccessibilitySettings()
            }
            3 -> { // Overlay
                requestOverlayPermission()
            }
            4 -> { // Contacts & Phone
                requestContactsPermission()
            }
            5 -> { // Notifications
                openNotificationListenerSettings()
            }
            6 -> { // Done
                completeOnboarding()
            }
        }
    }

    private fun requestMicrophonePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) {
            voiceManager.speak("Microphone permission granted.")
            moveToNext()
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MICROPHONE
            )
        }
    }

    private fun openAccessibilitySettings() {
        voiceManager.speak("I am opening Accessibility Settings. Please find Trix AI and turn it on.")
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivityForResult(intent, REQUEST_ACCESSIBILITY)
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(this)) {
                voiceManager.speak("Display overlay is already enabled.")
                moveToNext()
            } else {
                voiceManager.speak("Please enable display overlay for Trix AI.")
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivityForResult(intent, REQUEST_OVERLAY)
            }
        } else {
            moveToNext()
        }
    }

    private fun requestContactsPermission() {
        val permissions = arrayOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        if (allGranted) {
            voiceManager.speak("Contacts and phone permission granted.")
            moveToNext()
        } else {
            ActivityCompat.requestPermissions(this, permissions, REQUEST_CONTACTS)
        }
    }

    private fun openNotificationListenerSettings() {
        voiceManager.speak("Please enable notification access for Trix AI.")
        val intent = Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
        startActivityForResult(intent, REQUEST_NOTIFICATION)
    }

    private fun moveToNext() {
        currentStep++
        if (currentStep >= steps.size) {
            completeOnboarding()
        } else {
            updateStep()
        }
    }

    private fun updateStep() {
        val step = steps[currentStep]
        onboardingTitle.text = step.title
        onboardingDescription.text = step.description
        onboardingIcon.setImageResource(step.icon)
        pageIndicator.text = "${currentStep + 1} of ${steps.size}"

        if (currentStep == steps.size - 1) {
            nextButton.text = "Get Started"
            skipButton.visibility = View.GONE
        } else {
            nextButton.text = "Next"
            skipButton.visibility = View.VISIBLE
        }
    }

    private fun completeOnboarding() {
        lifecycleScope.launch {
            prefManager.setOnboardingComplete(true)
        }
        voiceManager.speak("Welcome to Trix AI. Your voice. Your phone. Your freedom.")
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_ACCESSIBILITY -> moveToNext()
            REQUEST_OVERLAY -> moveToNext()
            REQUEST_NOTIFICATION -> moveToNext()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_MICROPHONE -> moveToNext()
            REQUEST_CONTACTS -> moveToNext()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.destroy()
    }

    data class OnboardingStep(
        val title: String,
        val description: String,
        val icon: Int
    )

    companion object {
        private const val REQUEST_MICROPHONE = 200
        private const val REQUEST_ACCESSIBILITY = 201
        private const val REQUEST_OVERLAY = 202
        private const val REQUEST_CONTACTS = 203
        private const val REQUEST_NOTIFICATION = 204
    }
}
