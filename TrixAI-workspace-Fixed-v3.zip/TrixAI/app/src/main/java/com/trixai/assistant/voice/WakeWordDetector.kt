package com.trixai.assistant.voice

import android.content.Context
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import java.util.*

/**
 * Wake word detector that listens for "Hey Trix" using continuous recognition.
 * Battery-efficient: uses silence detection and periodic restart.
 */
class WakeWordDetector(private val context: Context) {

    private val TAG = "WakeWordDetector"
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var onWakeWordDetected: (() -> Unit)? = null

    fun setOnWakeWordDetected(listener: () -> Unit) {
        onWakeWordDetected = listener
    }

    fun start() {
        if (isListening) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "Speech recognition not available for wake word detection")
            return
        }

        isListening = true
        startListeningCycle()
    }

    fun stop() {
        isListening = false
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun startListeningCycle() {
        if (!isListening) return

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    // Restart listening after a short pause
                    restartAfterDelay(500)
                }

                override fun onError(error: Int) {
                    // Common errors during continuous listening are expected
                    if (error != SpeechRecognizer.ERROR_NO_MATCH &&
                        error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        Log.w(TAG, "Wake word recognition error: $error")
                    }
                    restartAfterDelay(1000)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.lowercase()?.trim()

                    if (text != null && isWakeWord(text)) {
                        Log.i(TAG, "Wake word detected: $text")
                        onWakeWordDetected?.invoke()
                    }

                    // Continue listening
                    restartAfterDelay(200)
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.lowercase()?.trim()

                    if (text != null && isWakeWord(text)) {
                        Log.i(TAG, "Wake word detected (partial): $text")
                        onWakeWordDetected?.invoke()
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }

        speechRecognizer?.startListening(intent)
    }

    private fun restartAfterDelay(delayMs: Long) {
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (isListening) {
                startListeningCycle()
            }
        }, delayMs)
    }

    private fun isWakeWord(text: String): Boolean {
        val normalized = text.lowercase().trim()
        return normalized.contains("hey trix") ||
                normalized.contains("hey tricks") ||
                normalized.contains("hey trics") ||
                normalized == "trix"
    }

    fun destroy() {
        stop()
    }
}
