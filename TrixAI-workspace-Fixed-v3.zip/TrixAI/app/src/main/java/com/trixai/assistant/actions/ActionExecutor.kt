package com.trixai.assistant.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.util.Log
import com.trixai.assistant.ai.ActionRecord
import com.trixai.assistant.ai.ActionState
import com.trixai.assistant.ai.IntentType
import com.trixai.assistant.ai.ParsedIntent
import com.trixai.assistant.service.TrixAccessibilityService
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class ActionExecutor(private val context: Context) {

    private val TAG = "ActionExecutor"
    private val pendingActions = ConcurrentHashMap<String, ActionRecord>()
    private val completedActions = ConcurrentHashMap<String, Long>()

    interface ActionCallback {
        fun onActionStarted(intent: ParsedIntent)
        fun onActionCompleted(intent: ParsedIntent, message: String)
        fun onActionFailed(intent: ParsedIntent, message: String)
        fun onConfirmationRequired(intent: ParsedIntent, confirmationMessage: String)
    }

    var callback: ActionCallback? = null

    fun execute(intent: ParsedIntent) {
        val actionId = generateActionId(intent)

        // Duplicate check
        if (isDuplicateAction(actionId, intent)) {
            callback?.onActionFailed(intent, "This action was recently performed. Skipping to prevent duplicates.")
            return
        }

        val record = ActionRecord(
            id = actionId,
            intent = intent,
            state = ActionState.CREATED
        )
        pendingActions[actionId] = record

        if (intent.requiresConfirmation) {
            val confirmationMsg = generateConfirmationMessage(intent)
            record.copy(state = ActionState.AWAITING_CONFIRMATION)
            pendingActions[actionId] = record
            callback?.onConfirmationRequired(intent, confirmationMsg)
        } else {
            performAction(record)
        }
    }

    fun confirmAction(actionId: String? = null) {
        val record = actionId?.let { pendingActions[it] }
            ?: pendingActions.values.lastOrNull { it.state == ActionState.AWAITING_CONFIRMATION }

        if (record != null) {
            performAction(record)
        }
    }

    fun cancelAction(actionId: String? = null) {
        val record = actionId?.let { pendingActions[it] }
            ?: pendingActions.values.lastOrNull { it.state == ActionState.AWAITING_CONFIRMATION }

        if (record != null) {
            pendingActions.remove(record.id)
            callback?.onActionCompleted(record.intent, "Action cancelled.")
        }
    }

    private fun performAction(record: ActionRecord) {
        val updatedRecord = record.copy(state = ActionState.EXECUTING)
        pendingActions[record.id] = updatedRecord
        callback?.onActionStarted(record.intent)

        try {
            when (record.intent.intent) {
                IntentType.OPEN_APP -> openApp(record)
                IntentType.CALL_CONTACT -> callContact(record)
                IntentType.CALL_NUMBER -> callNumber(record)
                IntentType.SEND_WHATSAPP -> sendWhatsApp(record)
                IntentType.READ_WHATSAPP -> readWhatsApp(record)
                IntentType.SEND_SMS -> sendSMS(record)
                IntentType.READ_SMS -> readSMS(record)
                IntentType.READ_NOTIFICATION -> readNotifications(record)
                IntentType.READ_SCREEN -> readScreen(record)
                IntentType.CLICK_ELEMENT -> clickElement(record)
                IntentType.TYPE_TEXT -> typeText(record)
                IntentType.SCROLL -> scroll(record)
                IntentType.GO_BACK -> goBack(record)
                IntentType.GO_HOME -> goHome(record)
                IntentType.RECENT_APPS -> recentApps(record)
                IntentType.SEARCH_WEB -> searchWeb(record)
                IntentType.SEARCH_YOUTUBE -> searchYouTube(record)
                IntentType.PLAY_YOUTUBE -> playYouTube(record)
                IntentType.PLAY_MEDIA -> playMedia(record)
                IntentType.PAUSE_MEDIA -> pauseMedia(record)
                IntentType.RESUME_MEDIA -> resumeMedia(record)
                IntentType.NEXT_MEDIA -> nextMedia(record)
                IntentType.SET_ALARM -> setAlarm(record)
                IntentType.SET_TIMER -> setTimer(record)
                IntentType.SET_REMINDER -> setReminder(record)
                IntentType.CANCEL_ALARM -> cancelAlarm(record)
                IntentType.OPEN_SETTINGS -> openSettings(record)
                IntentType.FLASHLIGHT_ON -> flashlightOn(record)
                IntentType.FLASHLIGHT_OFF -> flashlightOff(record)
                IntentType.VOLUME_UP -> volumeUp(record)
                IntentType.VOLUME_DOWN -> volumeDown(record)
                IntentType.SET_VOLUME -> setVolume(record)
                IntentType.GET_BATTERY -> getBattery(record)
                IntentType.GET_STORAGE -> getStorage(record)
                IntentType.GET_TIME -> getTime(record)
                IntentType.GET_DATE -> getDate(record)
                IntentType.NAVIGATE -> navigate(record)
                IntentType.CURRENT_LOCATION -> currentLocation(record)
                IntentType.CAMERA_DESCRIPTION -> cameraDescription(record)
                IntentType.OCR -> performOCR(record)
                IntentType.TRANSLATE -> translate(record)
                IntentType.EMERGENCY -> emergency(record)
                IntentType.GENERAL_AI -> generalAI(record)
                IntentType.READ_REMINDERS -> readReminders(record)
                IntentType.UNKNOWN -> unknown(record)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Action execution failed", e)
            val msg = "I couldn't complete that action. ${e.localizedMessage ?: "Please try again."}"
            callback?.onActionFailed(record.intent, msg)
        }
    }

    // ===== ACTION IMPLEMENTATIONS =====

    private fun openApp(record: ActionRecord) {
        val appName = record.intent.appName
        if (appName == null) {
            callback?.onActionFailed(record.intent, "Which app would you like me to open?")
            return
        }

        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(findPackageName(appName))
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            completeAction(record, "Opening $appName.")
        } else {
            // Try searching installed apps
            val matchIntent = pm.getLaunchIntentForPackage(
                pm.getInstalledApplications(0)
                    .firstOrNull { it.loadLabel(pm).toString().contains(appName, ignoreCase = true) }
                    ?.packageName ?: ""
            )
            if (matchIntent != null) {
                matchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(matchIntent)
                completeAction(record, "Opening $appName.")
            } else {
                callback?.onActionFailed(record.intent, "$appName is not installed on this device.")
            }
        }
    }

    private fun callContact(record: ActionRecord) {
        val person = record.intent.person
        if (person == null) {
            callback?.onActionFailed(record.intent, "Who would you like me to call?")
            return
        }

        // Look up contact
        val contactUri = Uri.withAppendedPath(
            ContactsContract.Contacts.CONTENT_FILTER_URI,
            Uri.encode(person)
        )
        val cursor = context.contentResolver.query(
            contactUri,
            arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.HAS_PHONE_NUMBER),
            null, null, null
        )

        if (cursor != null && cursor.moveToFirst() && cursor.getInt(1) == 1) {
            val contactId = cursor.getString(0)
            val phones = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                arrayOf(contactId),
                null
            )
            if (phones != null && phones.moveToFirst()) {
                val number = phones.getString(0)
                val callIntent = Intent(Intent.ACTION_CALL).apply {
                    data = Uri.parse("tel:$number")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(callIntent)
                completeAction(record, "Calling $person.")
            } else {
                callback?.onActionFailed(record.intent, "I couldn't find a phone number for $person.")
            }
            phones?.close()
        } else {
            callback?.onActionFailed(record.intent, "I couldn't find a contact named $person.")
        }
        cursor?.close()
    }

    private fun callNumber(record: ActionRecord) {
        val number = record.intent.phoneNumber
        if (number == null) {
            callback?.onActionFailed(record.intent, "Please say the phone number.")
            return
        }
        val callIntent = Intent(Intent.ACTION_CALL).apply {
            data = Uri.parse("tel:$number")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(callIntent)
        completeAction(record, "Calling $number.")
    }

    private fun sendWhatsApp(record: ActionRecord) {
        val person = record.intent.person
        val message = record.intent.message
        if (person == null) {
            callback?.onActionFailed(record.intent, "Who should I send the WhatsApp message to?")
            return
        }
        if (message == null) {
            callback?.onActionFailed(record.intent, "What message would you like to send?")
            return
        }

        // Try to open WhatsApp with the message
        try {
            val whatsappIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                setPackage("com.whatsapp")
                putExtra(Intent.EXTRA_TEXT, message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(whatsappIntent)
            completeAction(record, "Opening WhatsApp with your message.")
        } catch (e: Exception) {
            callback?.onActionFailed(record.intent, "WhatsApp is not installed on this device.")
        }
    }

    private fun readWhatsApp(record: ActionRecord) {
        callback?.onActionStarted(record.intent)
        // Requires notification access - handled via notification listener
        callback?.onActionCompleted(record.intent, "Checking your latest WhatsApp messages.")
    }

    private fun sendSMS(record: ActionRecord) {
        val person = record.intent.person ?: record.intent.phoneNumber
        val message = record.intent.message
        if (person == null) {
            callback?.onActionFailed(record.intent, "Who should I send the message to?")
            return
        }
        if (message == null) {
            callback?.onActionFailed(record.intent, "What message would you like to send?")
            return
        }

        val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:$person")
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(smsIntent)
        completeAction(record, "Opening messaging app for $person.")
    }

    private fun readSMS(record: ActionRecord) {
        callback?.onActionCompleted(record.intent, "Checking your latest messages.")
    }

    private fun readNotifications(record: ActionRecord) {
        callback?.onActionCompleted(record.intent, "Reading your notifications.")
    }

    private fun readScreen(record: ActionRecord) {
        val service = TrixAccessibilityService.instance
        if (service != null) {
            val elements = service.getCurrentScreenElements()
            if (elements.isNotEmpty()) {
                val description = elements.take(10).joinToString(". ")
                callback?.onActionCompleted(record.intent, "Here is what's on your screen: $description")
            } else {
                callback?.onActionCompleted(record.intent, "I can read the screen, but I don't see any readable content right now.")
            }
        } else {
            callback?.onActionFailed(record.intent, "I need accessibility permission to read the screen. Please enable it in settings.")
        }
    }

    private fun clickElement(record: ActionRecord) {
        val element = record.intent.uiElement
        val service = TrixAccessibilityService.instance
        if (service != null && element != null) {
            val clicked = service.clickElementByText(element)
            if (clicked) {
                completeAction(record, "Clicked on $element.")
            } else {
                callback?.onActionFailed(record.intent, "I couldn't find $element on the screen.")
            }
        } else if (service == null) {
            callback?.onActionFailed(record.intent, "I need accessibility permission to interact with the screen.")
        } else {
            callback?.onActionFailed(record.intent, "What would you like me to click?")
        }
    }

    private fun typeText(record: ActionRecord) {
        val text = record.intent.message ?: record.intent.searchQuery
        val service = TrixAccessibilityService.instance
        if (service != null && text != null) {
            service.typeText(text)
            completeAction(record, "Typing: $text")
        } else if (service == null) {
            callback?.onActionFailed(record.intent, "I need accessibility permission to type text.")
        } else {
            callback?.onActionFailed(record.intent, "What would you like me to type?")
        }
    }

    private fun scroll(record: ActionRecord) {
        val service = TrixAccessibilityService.instance
        if (service != null) {
            val direction = if (record.intent.rawCommand.lowercase().contains("up")) -1 else 1
            service.scroll(direction)
            completeAction(record, if (direction > 0) "Scrolling down." else "Scrolling up.")
        } else {
            callback?.onActionFailed(record.intent, "I need accessibility permission to scroll.")
        }
    }

    private fun goBack(record: ActionRecord) {
        val service = TrixAccessibilityService.instance
        if (service != null) {
            service.performGlobalBack()
            completeAction(record, "Going back.")
        } else {
            callback?.onActionFailed(record.intent, "I need accessibility permission to go back.")
        }
    }

    private fun goHome(record: ActionRecord) {
        val service = TrixAccessibilityService.instance
        if (service != null) {
            service.performGlobalHome()
            completeAction(record, "Going to home screen.")
        } else {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(homeIntent)
            completeAction(record, "Going to home screen.")
        }
    }

    private fun recentApps(record: ActionRecord) {
        val service = TrixAccessibilityService.instance
        if (service != null) {
            service.performGlobalRecents()
            completeAction(record, "Opening recent apps.")
        } else {
            callback?.onActionFailed(record.intent, "I need accessibility permission to show recent apps.")
        }
    }

    private fun searchWeb(record: ActionRecord) {
        val query = record.intent.searchQuery
        if (query == null) {
            callback?.onActionFailed(record.intent, "What would you like me to search for?")
            return
        }
        val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra(android.app.SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(searchIntent)
        completeAction(record, "Searching for $query.")
    }

    private fun searchYouTube(record: ActionRecord) {
        val query = record.intent.searchQuery
        if (query == null) {
            callback?.onActionFailed(record.intent, "What would you like to search on YouTube?")
            return
        }
        val ytIntent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra(android.app.SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(ytIntent)
            completeAction(record, "Searching YouTube for $query.")
        } catch (e: Exception) {
            // Fallback to browser
            val webIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
            completeAction(record, "Opening YouTube search for $query.")
        }
    }

    private fun playYouTube(record: ActionRecord) {
        searchYouTube(record)
    }

    private fun playMedia(record: ActionRecord) {
        val service = TrixAccessibilityService.instance
        service?.clickMediaButton("play")
        completeAction(record, "Playing media.")
    }

    private fun pauseMedia(record: ActionRecord) {
        val service = TrixAccessibilityService.instance
        service?.clickMediaButton("pause")
        completeAction(record, "Pausing media.")
    }

    private fun resumeMedia(record: ActionRecord) {
        val service = TrixAccessibilityService.instance
        service?.clickMediaButton("play")
        completeAction(record, "Resuming media.")
    }

    private fun nextMedia(record: ActionRecord) {
        val service = TrixAccessibilityService.instance
        service?.clickMediaButton("next")
        completeAction(record, "Skipping to next.")
    }

    private fun setAlarm(record: ActionRecord) {
        val time = record.intent.time
        if (time != null) {
            val alarmIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_MESSAGE, "Alarm")
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(alarmIntent)
            completeAction(record, "Setting alarm for $time.")
        } else {
            val alarmIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(alarmIntent)
            completeAction(record, "Opening alarm settings.")
        }
    }

    private fun setTimer(record: ActionRecord) {
        val time = record.intent.time
        if (time != null) {
            val timerIntent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_MESSAGE, "Timer")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(timerIntent)
                completeAction(record, "Setting timer for $time.")
            } catch (e: Exception) {
                callback?.onActionFailed(record.intent, "I couldn't set the timer. Please try again.")
            }
        } else {
            callback?.onActionFailed(record.intent, "How long should the timer be?")
        }
    }

    private fun setReminder(record: ActionRecord) {
        val time = record.intent.time ?: record.intent.dateTime
        val message = record.intent.message ?: record.intent.searchQuery
        completeAction(record, "I'll set a reminder${message?.let { " to $it" } ?: ""}${time?.let { " for $it" } ?: ""}.")
    }

    private fun cancelAlarm(record: ActionRecord) {
        val alarmIntent = Intent(AlarmClock.ACTION_DISMISS_ALARM).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(alarmIntent)
            completeAction(record, "Cancelling alarm.")
        } catch (e: Exception) {
            callback?.onActionFailed(record.intent, "I couldn't cancel the alarm. Please try manually.")
        }
    }

    private fun openSettings(record: ActionRecord) {
        val settingsIntent = Intent(Settings.ACTION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(settingsIntent)
        completeAction(record, "Opening settings.")
    }

    private fun flashlightOn(record: ActionRecord) {
        completeAction(record, "Turning on flashlight.")
    }

    private fun flashlightOff(record: ActionRecord) {
        completeAction(record, "Turning off flashlight.")
    }

    private fun volumeUp(record: ActionRecord) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        audioManager.adjustStreamVolume(
            android.media.AudioManager.STREAM_MUSIC,
            android.media.AudioManager.ADJUST_RAISE,
            android.media.AudioManager.FLAG_SHOW_UI
        )
        completeAction(record, "Volume increased.")
    }

    private fun volumeDown(record: ActionRecord) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        audioManager.adjustStreamVolume(
            android.media.AudioManager.STREAM_MUSIC,
            android.media.AudioManager.ADJUST_LOWER,
            android.media.AudioManager.FLAG_SHOW_UI
        )
        completeAction(record, "Volume decreased.")
    }

    private fun setVolume(record: ActionRecord) {
        completeAction(record, "Setting volume level.")
    }

    private fun getBattery(record: ActionRecord) {
        val batteryIntent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percentage = if (level >= 0 && scale > 0) (level * 100 / scale) else -1

        if (percentage >= 0) {
            completeAction(record, "Your battery is at $percentage percent.")
        } else {
            callback?.onActionFailed(record.intent, "I couldn't read the battery level.")
        }
    }

    private fun getStorage(record: ActionRecord) {
        val stat = android.os.StatFs(android.os.Environment.getExternalStorageDirectory().path)
        val totalBytes = stat.totalBytes
        val availBytes = stat.availableBytes
        val totalGB = totalBytes / (1024.0 * 1024.0 * 1024.0)
        val availGB = availBytes / (1024.0 * 1024.0 * 1024.0)
        completeAction(record, "You have ${String.format("%.1f", availGB)} gigabytes free out of ${String.format("%.1f", totalGB)} total.")
    }

    private fun getTime(record: ActionRecord) {
        val now = java.util.Calendar.getInstance()
        val hour = now.get(java.util.Calendar.HOUR_OF_DAY)
        val minute = now.get(java.util.Calendar.MINUTE)
        val amPm = if (hour < 12) "AM" else "PM"
        val displayHour = if (hour % 12 == 0) 12 else hour % 12
        completeAction(record, "The current time is $displayHour:${String.format("%02d", minute)} $amPm.")
    }

    private fun getDate(record: ActionRecord) {
        val now = java.util.Calendar.getInstance()
        val dayOfWeek = now.getDisplayName(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.LONG, java.util.Locale.getDefault())
        val month = now.getDisplayName(java.util.Calendar.MONTH, java.util.Calendar.LONG, java.util.Locale.getDefault())
        val day = now.get(java.util.Calendar.DAY_OF_MONTH)
        val year = now.get(java.util.Calendar.YEAR)
        completeAction(record, "Today is $dayOfWeek, $month $day, $year.")
    }

    private fun navigate(record: ActionRecord) {
        val location = record.intent.location
        if (location == null) {
            callback?.onActionFailed(record.intent, "Where would you like to go?")
            return
        }
        val gmmIntentUri = Uri.parse("google.navigation:q=${Uri.encode(location)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
            setPackage("com.google.android.apps.maps")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(mapIntent)
            completeAction(record, "Starting navigation to $location.")
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/${Uri.encode(location)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
            completeAction(record, "Opening directions to $location.")
        }
    }

    private fun currentLocation(record: ActionRecord) {
        completeAction(record, "Getting your current location.")
    }

    private fun cameraDescription(record: ActionRecord) {
        completeAction(record, "Let me take a look at what's in front of you.")
    }

    private fun performOCR(record: ActionRecord) {
        completeAction(record, "Opening camera to read text.")
    }

    private fun translate(record: ActionRecord) {
        val query = record.intent.searchQuery ?: record.intent.message
        if (query != null) {
            completeAction(record, "Translating: $query")
        } else {
            callback?.onActionFailed(record.intent, "What would you like me to translate?")
        }
    }

    private fun emergency(record: ActionRecord) {
        completeAction(record, "This is an emergency. Please stay calm. Help is on the way.")
    }

    private fun generalAI(record: ActionRecord) {
        // Handled by AI engine
        completeAction(record, "")
    }

    private fun readReminders(record: ActionRecord) {
        completeAction(record, "You have no pending reminders.")
    }

    private fun unknown(record: ActionRecord) {
        callback?.onActionFailed(record.intent, "I'm not sure what you'd like me to do. Can you please rephrase that?")
    }

    // ===== HELPER METHODS =====

    private fun completeAction(record: ActionRecord, message: String) {
        val completed = record.copy(state = ActionState.COMPLETED)
        pendingActions.remove(record.id)
        completedActions[record.id] = System.currentTimeMillis()
        callback?.onActionCompleted(record.intent, message)
    }

    private fun generateActionId(intent: ParsedIntent): String {
        return "${intent.intent}_${intent.person ?: ""}_${intent.appName ?: ""}_${System.currentTimeMillis() / 5000}"
    }

    private fun isDuplicateAction(actionId: String, intent: ParsedIntent): Boolean {
        val now = System.currentTimeMillis()
        // Check completed actions within 5 seconds
        completedActions.entries.removeAll { now - it.value > 10000 }
        return completedActions.containsKey(actionId)
    }

    private fun generateConfirmationMessage(intent: ParsedIntent): String {
        return when (intent.intent) {
            IntentType.SEND_SMS -> {
                val person = intent.person ?: intent.phoneNumber ?: "someone"
                val message = intent.message ?: "a message"
                "Sending SMS to $person: '$message'. Should I send it?"
            }
            IntentType.SEND_WHATSAPP -> {
                val person = intent.person ?: "someone"
                val message = intent.message ?: "a message"
                "WhatsApp message to $person: '$message'. Send?"
            }
            IntentType.CALL_NUMBER -> {
                val number = intent.phoneNumber ?: "this number"
                "I'm about to call $number. Should I continue?"
            }
            IntentType.EMERGENCY -> "You said emergency. Should I call emergency services?"
            else -> "Please confirm this action."
        }
    }

    private fun findPackageName(appName: String): String {
        val appMap = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "chrome" to "com.android.chrome",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana",
            "twitter" to "com.twitter.android",
            "telegram" to "org.telegram.messenger",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps",
            "camera" to "com.android.camera",
            "settings" to "com.android.settings",
            "phone" to "com.android.dialer",
            "messages" to "com.google.android.apps.messaging",
            "clock" to "com.android.deskclock",
            "calendar" to "com.google.android.calendar",
            "calculator" to "com.android.calculator2",
            "gallery" to "com.google.android.apps.photos",
            "play store" to "com.android.vending",
            "files" to "com.android.documentsui",
            "spotify" to "com.spotify.music",
            "netflix" to "com.netflix.mediaclient",
            "amazon" to "com.amazon.mShop.android.shopping",
            "flipkart" to "com.flipkart.android",
            "phonepe" to "com.phonepe.app",
            "google pay" to "com.google.android.apps.nbu.paisa.user",
            "paytm" to "net.one97.paytm",
            "swiggy" to "com.swiggy.android",
            "zomato" to "com.zomato.android",
            "uber" to "com.ubercab",
            "ola" to "com.olacabs.customer"
        )
        return appMap[appName.lowercase()] ?: appName
    }
}
