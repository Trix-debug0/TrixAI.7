package com.trixai.assistant.ui.splash

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.animation.AlphaAnimation
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.trixai.assistant.R
import com.trixai.assistant.TrixAIApplication
import com.trixai.assistant.ui.main.MainActivity
import com.trixai.assistant.ui.onboarding.OnboardingActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val titleText = findViewById<TextView>(R.id.splashTitle)
        val taglineText = findViewById<TextView>(R.id.splashTagline)
        val logoImage = findViewById<ImageView>(R.id.splashLogo)

        // Fade in animation
        val fadeIn = AlphaAnimation(0f, 1f).apply {
            duration = 1200
            fillAfter = true
        }

        val fadeInDelayed = AlphaAnimation(0f, 1f).apply {
            duration = 1200
            startOffset = 400
            fillAfter = true
        }

        logoImage.startAnimation(fadeIn)
        titleText.startAnimation(fadeIn)
        taglineText.startAnimation(fadeInDelayed)

        lifecycleScope.launch {
            delay(2500)
            val app = application as TrixAIApplication
            val onboardingDone = app.preferenceManager.onboardingComplete.first()

            val targetIntent = if (onboardingDone) {
                Intent(this@SplashActivity, MainActivity::class.java)
            } else {
                Intent(this@SplashActivity, OnboardingActivity::class.java)
            }
            startActivity(targetIntent)
            finish()
        }
    }
}
