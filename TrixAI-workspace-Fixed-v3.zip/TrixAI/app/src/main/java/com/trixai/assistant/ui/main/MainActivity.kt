package com.trixai.assistant.ui.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.trixai.assistant.R
import com.trixai.assistant.TrixAIApplication
import com.trixai.assistant.service.TrixForegroundService
import com.trixai.assistant.ui.settings.SettingsActivity
import com.trixai.assistant.viewmodel.AssistantStatus
import com.trixai.assistant.viewmodel.MainViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()
    private lateinit var micButton: ImageButton
    private lateinit var statusText: TextView
    private lateinit var brandText: TextView
    private lateinit var conversationText: TextView
    private lateinit var settingsButton: ImageButton
    private lateinit var statusIndicator: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupListeners()
        observeState()
        startForegroundServiceIfNeeded()

        // Check if triggered from overlay or quick settings
        if (intent?.getBooleanExtra("TRIGGER_VOICE", false) == true) {
            lifecycleScope.launch {
                kotlinx.coroutines.delay(300)
                viewModel.startListening()
            }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.getBooleanExtra("TRIGGER_VOICE", false) == true) {
            lifecycleScope.launch {
                kotlinx.coroutines.delay(300)
                viewModel.startListening()
            }
        }
    }

    private fun initViews() {
        micButton = findViewById(R.id.micButton)
        statusText = findViewById(R.id.statusText)
        brandText = findViewById(R.id.brandText)
        conversationText = findViewById(R.id.conversationText)
        settingsButton = findViewById(R.id.settingsButton)
        statusIndicator = findViewById(R.id.statusIndicator)
    }

    private fun setupListeners() {
        micButton.setOnClickListener {
            performHapticFeedback()
            when (viewModel.statusState.value) {
                AssistantStatus.AWAITING_CONFIRMATION -> viewModel.confirmPendingAction()
                AssistantStatus.LISTENING -> viewModel.stopListening()
                else -> {
                    requestMicrophonePermission {
                        viewModel.startListening()
                    }
                }
            }
        }

        micButton.setOnLongClickListener {
            performHapticFeedback()
            val settingsIntent = Intent(this, SettingsActivity::class.java)
            startActivity(settingsIntent)
            true
        }

        settingsButton.setOnClickListener {
            val settingsIntent = Intent(this, SettingsActivity::class.java)
            startActivity(settingsIntent)
        }
    }

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.statusText.collect { text ->
                        statusText.text = text
                        // Update accessibility
                        statusText.contentDescription = text
                    }
                }
                launch {
                    viewModel.statusState.collect { state ->
                        updateUIForState(state)
                    }
                }
                launch {
                    viewModel.conversationHistory.collect { messages ->
                        val lastMessage = messages.lastOrNull()
                        if (lastMessage != null) {
                            conversationText.text = lastMessage.text
                            conversationText.visibility = View.VISIBLE
                        } else {
                            conversationText.visibility = View.GONE
                        }
                    }
                }
            }
        }
    }

    private fun updateUIForState(state: AssistantStatus) {
        when (state) {
            AssistantStatus.READY -> {
                micButton.setImageResource(R.drawable.ic_mic_black)
                micButton.isEnabled = true
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_ready)
                brandText.text = "Trix AI"
            }
            AssistantStatus.LISTENING -> {
                micButton.setImageResource(R.drawable.ic_mic_black)
                micButton.isEnabled = true
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_listening)
                animateListening()
            }
            AssistantStatus.PROCESSING -> {
                micButton.setImageResource(R.drawable.ic_mic_black)
                micButton.isEnabled = false
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_processing)
            }
            AssistantStatus.WORKING -> {
                micButton.setImageResource(R.drawable.ic_mic_black)
                micButton.isEnabled = false
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_working)
            }
            AssistantStatus.SPEAKING -> {
                micButton.setImageResource(R.drawable.ic_speaker)
                micButton.isEnabled = true
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_speaking)
            }
            AssistantStatus.COMPLETE -> {
                micButton.setImageResource(R.drawable.ic_check)
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_ready)
            }
            AssistantStatus.ERROR -> {
                micButton.setImageResource(R.drawable.ic_mic_black)
                micButton.isEnabled = true
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_error)
            }
            AssistantStatus.AWAITING_CONFIRMATION -> {
                micButton.setImageResource(R.drawable.ic_check)
                micButton.isEnabled = true
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_confirm)
            }
            AssistantStatus.OFFLINE -> {
                micButton.setImageResource(R.drawable.ic_mic_black)
                micButton.isEnabled = true
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_error)
            }
        }
    }

    private fun animateListening() {
        // Pulsing animation for mic button
        micButton.animate()
            .scaleX(1.1f)
            .scaleY(1.1f)
            .setDuration(500)
            .withEndAction {
                micButton.animate()
                    .scaleX(1.0f)
                    .scaleY(1.0f)
                    .setDuration(500)
                    .start()
            }
            .start()
    }

    private fun performHapticFeedback() {
        lifecycleScope.launch {
            val app = application as TrixAIApplication
            val enabled = app.preferenceManager.hapticEnabled.first()
            if (enabled) {
                val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(50)
                }
            }
        }
    }

    private fun requestMicrophonePermission(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) {
            onGranted()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_MICROPHONE
            )
            pendingAction = onGranted
        }
    }

    private var pendingAction: (() -> Unit)? = null

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MICROPHONE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pendingAction?.invoke()
            } else {
                viewModel.voiceManager.speak("Microphone permission is needed for voice commands.")
            }
            pendingAction = null
        }
    }

    private fun startForegroundServiceIfNeeded() {
        lifecycleScope.launch {
            val app = application as TrixAIApplication
            val enabled = app.preferenceManager.backgroundServiceEnabled.first()
            if (enabled) {
                val intent = Intent(this@MainActivity, TrixForegroundService::class.java).apply {
                    action = TrixForegroundService.ACTION_START
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(intent)
                } else {
                    startService(intent)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh state when returning
        updateAccessibilityStatus()
    }

    private fun updateAccessibilityStatus() {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val isTalkBackEnabled = am.isTouchExplorationEnabled
        // Adjust UI for TalkBack if needed
        if (isTalkBackEnabled) {
            micButton.contentDescription = "Trix AI microphone. Double tap to start speaking."
        }
    }

    companion object {
        private const val REQUEST_MICROPHONE = 100
    }
}
