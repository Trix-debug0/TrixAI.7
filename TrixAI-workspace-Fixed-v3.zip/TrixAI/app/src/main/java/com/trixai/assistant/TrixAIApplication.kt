package com.trixai.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.trixai.assistant.util.PreferenceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class TrixAIApplication : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var preferenceManager: PreferenceManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        preferenceManager = PreferenceManager(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        val serviceChannel = NotificationChannel(
            CHANNEL_FOREGROUND,
            "Trix AI Assistant Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps Trix AI running in the background"
            setShowBadge(false)
        }

        val actionChannel = NotificationChannel(
            CHANNEL_ACTIONS,
            "Trix AI Actions",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Action notifications from Trix AI"
        }

        val alertChannel = NotificationChannel(
            CHANNEL_ALERTS,
            "Trix AI Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Important alerts from Trix AI"
            enableVibration(true)
        }

        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(serviceChannel)
        manager.createNotificationChannel(actionChannel)
        manager.createNotificationChannel(alertChannel)
    }

    companion object {
        const val CHANNEL_FOREGROUND = "trix_foreground_service"
        const val CHANNEL_ACTIONS = "trix_actions"
        const val CHANNEL_ALERTS = "trix_alerts"

        lateinit var instance: TrixAIApplication
            private set
    }
}
