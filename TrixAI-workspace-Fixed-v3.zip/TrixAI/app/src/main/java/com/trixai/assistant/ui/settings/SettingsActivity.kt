package com.trixai.assistant.ui.settings

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.trixai.assistant.R
import com.trixai.assistant.TrixAIApplication
import com.trixai.assistant.service.TrixAccessibilityService
import com.trixai.assistant.util.PreferenceManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefManager: PreferenceManager

    // Assistant
    private lateinit var voiceLanguageSpinner: Spinner
    private lateinit var wakeWordSwitch: Switch
    private lateinit var confirmationSpinner: Spinner

    // Activation
    private lateinit var overlaySwitch: Switch
    private lateinit var quickSettingsText: TextView
    private lateinit var powerButtonStatus: TextView

    // Accessibility
    private lateinit var hapticSwitch: Switch
    private lateinit var speechSwitch: Switch
    private lateinit var accessibilityStatus: TextView

    // Privacy
    private lateinit var micPermissionStatus: TextView
    private lateinit var cameraPermissionStatus: TextView
    private lateinit var contactPermissionStatus: TextView
    private lateinit var smsPermissionStatus: TextView
    private lateinit var notificationPermissionStatus: TextView
    private lateinit var locationPermissionStatus: TextView

    // Appearance
    private lateinit var textSizeSpinner: Spinner
    private lateinit var buttonSizeSpinner: Spinner

    // About
    private lateinit var versionText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        prefManager = (application as TrixAIApplication).preferenceManager

        initViews()
        setupBackButton()
        loadCurrentSettings()
        setupListeners()
    }

    private fun initViews() {
        // Assistant
        voiceLanguageSpinner = findViewById(R.id.voiceLanguageSpinner)
        wakeWordSwitch = findViewById(R.id.wakeWordSwitch)
        confirmationSpinner = findViewById(R.id.confirmationSpinner)

        // Activation
        overlaySwitch = findViewById(R.id.overlaySwitch)
        quickSettingsText = findViewById(R.id.quickSettingsText)
        powerButtonStatus = findViewById(R.id.powerButtonStatus)

        // Accessibility
        hapticSwitch = findViewById(R.id.hapticSwitch)
        speechSwitch = findViewById(R.id.speechSwitch)
        accessibilityStatus = findViewById(R.id.accessibilityStatus)

        // Privacy
        micPermissionStatus = findViewById(R.id.micPermissionStatus)
        cameraPermissionStatus = findViewById(R.id.cameraPermissionStatus)
        contactPermissionStatus = findViewById(R.id.contactPermissionStatus)
        smsPermissionStatus = findViewById(R.id.smsPermissionStatus)
        notificationPermissionStatus = findViewById(R.id.notificationPermissionStatus)
        locationPermissionStatus = findViewById(R.id.locationPermissionStatus)

        // Appearance
        textSizeSpinner = findViewById(R.id.textSizeSpinner)
        buttonSizeSpinner = findViewById(R.id.buttonSizeSpinner)

        // About
        versionText = findViewById(R.id.versionText)
    }

    private fun setupBackButton() {
        findViewById<ImageView>(R.id.backButton).setOnClickListener {
            finish()
        }
    }

    private fun loadCurrentSettings() {
        // Setup spinners
        setupSpinners()
        loadSwitches()
        updatePermissionStatuses()
        updateAccessibilityStatus()
        updatePowerButtonStatus()

        versionText.text = "Trix AI v1.0.0"
    }

    private fun setupSpinners() {
        // Voice Language
        val languages = arrayOf("Auto Detect", "English", "Hindi", "Urdu")
        voiceLanguageSpinner.adapter = ArrayAdapter(this, R.layout.spinner_item, languages)

        // Confirmation Level
        val confirmations = arrayOf("Always Ask", "Smart", "Never")
        confirmationSpinner.adapter = ArrayAdapter(this, R.layout.spinner_item, confirmations)

        // Text Size
        val textSizes = arrayOf("Small", "Medium", "Large", "Extra Large")
        textSizeSpinner.adapter = ArrayAdapter(this, R.layout.spinner_item, textSizes)

        // Button Size
        val buttonSizes = arrayOf("Small", "Medium", "Large")
        buttonSizeSpinner.adapter = ArrayAdapter(this, R.layout.spinner_item, buttonSizes)
    }

    private fun loadSwitches() {
        lifecycleScope.launch {
            wakeWordSwitch.isChecked = prefManager.wakeWordEnabled.first()
            overlaySwitch.isChecked = prefManager.overlayEnabled.first()
            hapticSwitch.isChecked = prefManager.hapticEnabled.first()
            speechSwitch.isChecked = prefManager.speechFeedbackEnabled.first()
        }
    }

    private fun setupListeners() {
        wakeWordSwitch.setOnCheckedChangeListener { _, isChecked ->
            lifecycleScope.launch { prefManager.setWakeWordEnabled(isChecked) }
        }

        overlaySwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    overlaySwitch.isChecked = false
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } else {
                    lifecycleScope.launch { prefManager.setOverlayEnabled(true) }
                }
            } else {
                lifecycleScope.launch { prefManager.setOverlayEnabled(false) }
            }
        }

        hapticSwitch.setOnCheckedChangeListener { _, isChecked ->
            lifecycleScope.launch { prefManager.setHapticEnabled(isChecked) }
        }

        speechSwitch.setOnCheckedChangeListener { _, isChecked ->
            lifecycleScope.launch { prefManager.setSpeechFeedback(isChecked) }
        }

        voiceLanguageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val lang = when (position) {
                    0 -> "auto"
                    1 -> "english"
                    2 -> "hindi"
                    3 -> "urdu"
                    else -> "auto"
                }
                lifecycleScope.launch { prefManager.setVoiceLanguage(lang) }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Permission clicks
        micPermissionStatus.setOnClickListener { requestPermission(Manifest.permission.RECORD_AUDIO, 300) }
        cameraPermissionStatus.setOnClickListener { requestPermission(Manifest.permission.CAMERA, 301) }
        contactPermissionStatus.setOnClickListener {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), 302)
        }
        smsPermissionStatus.setOnClickListener {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS), 303)
        }
        locationPermissionStatus.setOnClickListener {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 304)
        }
        notificationPermissionStatus.setOnClickListener {
            val intent = Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
            startActivity(intent)
        }
        accessibilityStatus.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }
    }

    private fun requestPermission(permission: String, requestCode: Int) {
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(permission), requestCode)
        }
    }

    private fun updatePermissionStatuses() {
        micPermissionStatus.text = getPermissionStatus(Manifest.permission.RECORD_AUDIO)
        cameraPermissionStatus.text = getPermissionStatus(Manifest.permission.CAMERA)
        contactPermissionStatus.text = getPermissionStatus(Manifest.permission.READ_CONTACTS)
        smsPermissionStatus.text = getPermissionStatus(Manifest.permission.SEND_SMS)
        locationPermissionStatus.text = getPermissionStatus(Manifest.permission.ACCESS_FINE_LOCATION)
        notificationPermissionStatus.text = if (isNotificationListenerEnabled()) "Enabled" else "Not enabled - Tap to enable"
    }

    private fun getPermissionStatus(permission: String): String {
        return if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            "Granted"
        } else {
            "Not granted - Tap to enable"
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat?.contains(packageName) == true
    }

    private fun updateAccessibilityStatus() {
        val isAccessibilityEnabled = TrixAccessibilityService.instance != null
        accessibilityStatus.text = if (isAccessibilityEnabled) "Enabled" else "Not enabled - Tap to enable"
    }

    private fun updatePowerButtonStatus() {
        // Power button long press interception is device-specific
        powerButtonStatus.text = "Requires device-specific configuration\nNot supported on all devices"
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatuses()
        updateAccessibilityStatus()
    }
}
