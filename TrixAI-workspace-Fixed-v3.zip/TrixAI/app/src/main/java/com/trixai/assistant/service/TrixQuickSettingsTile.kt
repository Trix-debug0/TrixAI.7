package com.trixai.assistant.service

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.trixai.assistant.ui.main.MainActivity

@RequiresApi(Build.VERSION_CODES.N)
class TrixQuickSettingsTile : TileService() {

    override fun onStartListening() {
        qsTile?.state = Tile.STATE_INACTIVE
        qsTile?.label = "Trix AI"
        qsTile?.updateTile()
    }

    override fun onClick() {
        val intent = android.content.Intent(this, MainActivity::class.java).apply {
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("TRIGGER_VOICE", true)
        }
        startActivityAndCollapse(intent)
    }
}
