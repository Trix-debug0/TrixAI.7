package com.trixai.assistant.ai

data class ParsedIntent(
    val intent: IntentType,
    val confidence: Float = 0f,
    val person: String? = null,
    val phoneNumber: String? = null,
    val message: String? = null,
    val appName: String? = null,
    val searchQuery: String? = null,
    val dateTime: String? = null,
    val time: String? = null,
    val location: String? = null,
    val uiElement: String? = null,
    val language: DetectedLanguage = DetectedLanguage.ENGLISH,
    val requiresConfirmation: Boolean = false,
    val rawCommand: String = ""
)

enum class IntentType {
    OPEN_APP,
    CALL_CONTACT,
    CALL_NUMBER,
    SEND_WHATSAPP,
    READ_WHATSAPP,
    SEND_SMS,
    READ_SMS,
    READ_NOTIFICATION,
    READ_SCREEN,
    CLICK_ELEMENT,
    TYPE_TEXT,
    SCROLL,
    GO_BACK,
    GO_HOME,
    RECENT_APPS,
    SEARCH_WEB,
    SEARCH_YOUTUBE,
    PLAY_YOUTUBE,
    PLAY_MEDIA,
    PAUSE_MEDIA,
    RESUME_MEDIA,
    NEXT_MEDIA,
    SET_ALARM,
    SET_TIMER,
    SET_REMINDER,
    CANCEL_ALARM,
    READ_REMINDERS,
    OPEN_SETTINGS,
    FLASHLIGHT_ON,
    FLASHLIGHT_OFF,
    VOLUME_UP,
    VOLUME_DOWN,
    SET_VOLUME,
    GET_BATTERY,
    GET_STORAGE,
    GET_TIME,
    GET_DATE,
    NAVIGATE,
    CURRENT_LOCATION,
    CAMERA_DESCRIPTION,
    OCR,
    TRANSLATE,
    EMERGENCY,
    GENERAL_AI,
    UNKNOWN
}

enum class DetectedLanguage {
    ENGLISH,
    HINDI,
    URDU,
    HINGLISH,
    MIXED
}

enum class ActionState {
    CREATED,
    AWAITING_CONFIRMATION,
    EXECUTING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class ActionRecord(
    val id: String,
    val intent: ParsedIntent,
    val state: ActionState,
    val timestamp: Long = System.currentTimeMillis()
)
