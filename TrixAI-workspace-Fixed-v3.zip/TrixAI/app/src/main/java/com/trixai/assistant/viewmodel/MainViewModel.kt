package com.trixai.assistant.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.trixai.assistant.TrixAIApplication
import com.trixai.assistant.actions.ActionExecutor
import com.trixai.assistant.ai.*
import com.trixai.assistant.voice.VoiceManager
import com.trixai.assistant.voice.VoiceState
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as TrixAIApplication
    private val prefManager = app.preferenceManager

    val voiceManager = VoiceManager(application, prefManager)
    val actionExecutor = ActionExecutor(application)
    private val intentParser = IntentParser()
    private val aiEngine = AIEngine(prefManager)

    private val _statusText = MutableStateFlow("Trix AI Ready")
    val statusText: StateFlow<String> = _statusText

    private val _statusState = MutableStateFlow(AssistantStatus.READY)
    val statusState: StateFlow<AssistantStatus> = _statusState

    private val _conversationHistory = MutableStateFlow<List<ConversationMessage>>(emptyList())
    val conversationHistory: StateFlow<List<ConversationMessage>> = _conversationHistory

    private val _isWakeWordActive = MutableStateFlow(false)
    val isWakeWordActive: StateFlow<Boolean> = _isWakeWordActive

    val voiceLanguage: StateFlow<String> = prefManager.voiceLanguage.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "auto")

    private var conversationContext = ConversationContext()

    init {
        setupActionCallback()
        setupVoiceCallbacks()
        observeVoiceState()
    }

    private fun setupVoiceCallbacks() {
        voiceManager.onResult = { text ->
            processCommand(text)
        }
        voiceManager.onError = { error ->
            _statusText.value = error
            _statusState.value = AssistantStatus.ERROR
            voiceManager.speak(error)
        }
        voiceManager.onPartialResult = { partial ->
            _statusText.value = partial
        }
    }

    private fun setupActionCallback() {
        actionExecutor.callback = object : ActionExecutor.ActionCallback {
            override fun onActionStarted(intent: ParsedIntent) {
                _statusText.value = "Working..."
                _statusState.value = AssistantStatus.WORKING
            }

            override fun onActionCompleted(intent: ParsedIntent, message: String) {
                if (message.isNotBlank()) {
                    _statusText.value = "Done"
                    _statusState.value = AssistantStatus.COMPLETE
                    voiceManager.speak(message) {
                        resetToReady()
                    }
                    addConversationMessage("assistant", message)
                } else {
                    resetToReady()
                }
            }

            override fun onActionFailed(intent: ParsedIntent, message: String) {
                _statusText.value = message
                _statusState.value = AssistantStatus.ERROR
                voiceManager.speak(message) {
                    resetToReady()
                }
                addConversationMessage("assistant", message)
            }

            override fun onConfirmationRequired(intent: ParsedIntent, confirmationMessage: String) {
                _statusText.value = "Waiting for confirmation"
                _statusState.value = AssistantStatus.AWAITING_CONFIRMATION
                voiceManager.speak(confirmationMessage)
                addConversationMessage("assistant", confirmationMessage)
            }
        }
    }

    private fun observeVoiceState() {
        viewModelScope.launch {
            voiceManager.state.collect { state ->
                when (state) {
                    VoiceState.IDLE -> {
                        if (_statusState.value == AssistantStatus.LISTENING) {
                            resetToReady()
                        }
                    }
                    VoiceState.LISTENING -> {
                        _statusText.value = "Listening..."
                        _statusState.value = AssistantStatus.LISTENING
                    }
                    VoiceState.PROCESSING -> {
                        _statusText.value = "Thinking..."
                        _statusState.value = AssistantStatus.PROCESSING
                    }
                    VoiceState.SPEAKING -> {
                        _statusText.value = "Speaking..."
                        _statusState.value = AssistantStatus.SPEAKING
                    }
                    VoiceState.WORKING -> {
                        _statusText.value = "Working..."
                        _statusState.value = AssistantStatus.WORKING
                    }
                    VoiceState.ERROR -> {
                        _statusState.value = AssistantStatus.ERROR
                    }
                }
            }
        }
    }

    fun startListening() {
        viewModelScope.launch {
            val langStr = voiceLanguage.first()
            val language = when (langStr) {
                "hindi" -> DetectedLanguage.HINDI
                "urdu" -> DetectedLanguage.URDU
                else -> DetectedLanguage.ENGLISH
            }
            voiceManager.startListening(language)
        }
    }

    fun stopListening() {
        voiceManager.stopListening()
    }

    fun confirmPendingAction() {
        actionExecutor.confirmAction()
    }

    fun cancelPendingAction() {
        actionExecutor.cancelAction()
    }

    private fun processCommand(text: String) {
        addConversationMessage("user", text)

        // Check for wake word response
        if (text.lowercase().contains("yes") || text.lowercase().contains("haan") ||
            text.lowercase().contains("ha") || text.lowercase().contains("ji")) {
            if (_statusState.value == AssistantStatus.AWAITING_CONFIRMATION) {
                actionExecutor.confirmAction()
                return
            }
        }
        if (text.lowercase().contains("no") || text.lowercase().contains("nahi") ||
            text.lowercase().contains("cancel") || text.lowercase().contains("mat")) {
            if (_statusState.value == AssistantStatus.AWAITING_CONFIRMATION) {
                actionExecutor.cancelAction()
                return
            }
        }

        // Check for wake word
        if (isWakeWord(text)) {
            _isWakeWordActive.value = true
            voiceManager.speak("I'm listening.") {
                startListening()
            }
            return
        }

        // Parse intent
        val parsedIntent = intentParser.parse(text)
        _statusText.value = "Thinking..."
        _statusState.value = AssistantStatus.PROCESSING

        when (parsedIntent.intent) {
            IntentType.GENERAL_AI -> {
                viewModelScope.launch {
                    val response = aiEngine.generateResponse(text, conversationContext)
                    voiceManager.speak(response) {
                        resetToReady()
                    }
                    addConversationMessage("assistant", response)
                }
            }
            IntentType.UNKNOWN -> {
                val response = "I'm not sure what you'd like me to do. Can you please rephrase that?"
                voiceManager.speak(response) { resetToReady() }
                addConversationMessage("assistant", response)
            }
            else -> {
                actionExecutor.execute(parsedIntent)
            }
        }

        // Update conversation context
        conversationContext = conversationContext.copy(lastIntent = parsedIntent)
    }

    private fun isWakeWord(text: String): Boolean {
        val lower = text.lowercase().trim()
        return lower.contains("hey trix") || lower.contains("hey tricks") || lower == "trix"
    }

    private fun addConversationMessage(role: String, text: String) {
        val msg = ConversationMessage(role, text, System.currentTimeMillis())
        _conversationHistory.value = _conversationHistory.value + msg
        conversationContext = conversationContext.copy(
            history = conversationContext.history + MessagePair(
                if (role == "user") text else "",
                if (role == "assistant") text else ""
            )
        )
    }

    private fun resetToReady() {
        _statusText.value = "Trix AI Ready"
        _statusState.value = AssistantStatus.READY
        _isWakeWordActive.value = false
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}

enum class AssistantStatus {
    READY,
    LISTENING,
    PROCESSING,
    WORKING,
    SPEAKING,
    COMPLETE,
    ERROR,
    AWAITING_CONFIRMATION,
    OFFLINE
}

data class ConversationMessage(
    val role: String,
    val text: String,
    val timestamp: Long
)
