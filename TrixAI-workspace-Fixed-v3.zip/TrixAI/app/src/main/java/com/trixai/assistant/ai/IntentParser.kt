package com.trixai.assistant.ai

import android.util.Patterns

class IntentParser {

    fun parse(text: String): ParsedIntent {
        val normalized = text.trim().lowercase()
        val language = detectLanguage(text)

        // Extract entities
        val person = extractPerson(normalized, text)
        val phone = extractPhoneNumber(text)
        val app = extractAppName(normalized)
        val message = extractMessage(normalized, text)
        val time = extractTime(normalized, text)
        val date = extractDate(normalized, text)
        val location = extractLocation(normalized, text)
        val searchQuery = extractSearchQuery(normalized, text)
        val uiElement = extractUIElement(normalized, text)

        val intent = determineIntent(normalized, text)
        val requiresConfirmation = intent in SENSITIVE_INTENTS

        return ParsedIntent(
            intent = intent,
            confidence = calculateConfidence(normalized, intent),
            person = person,
            phoneNumber = phone,
            message = message,
            appName = app,
            searchQuery = searchQuery,
            dateTime = date,
            time = time,
            location = location,
            uiElement = uiElement,
            language = language,
            requiresConfirmation = requiresConfirmation,
            rawCommand = text
        )
    }

    fun detectLanguage(text: String): DetectedLanguage {
        val hasDevanagari = text.any { it in '\u0900'..'\u097F' }
        val hasUrdu = text.any { it in '\u0600'..'\u06FF' }
        val hasRomanHindi = ROMAN_HINDI_INDICATORS.any { text.lowercase().contains(it) }
        val hasEnglish = text.any { it in 'a'..'z' || it in 'A'..'Z' }

        return when {
            hasUrdu -> DetectedLanguage.URDU
            hasDevanagari -> DetectedLanguage.HINDI
            hasRomanHindi && hasEnglish -> DetectedLanguage.HINGLISH
            hasRomanHindi -> DetectedLanguage.HINDI
            else -> DetectedLanguage.ENGLISH
        }
    }

    private fun determineIntent(normalized: String, original: String): IntentType {
        // Emergency
        if (matchesEmergency(normalized)) return IntentType.EMERGENCY

        // Flashlight
        if (matchesFlashlightOn(normalized)) return IntentType.FLASHLIGHT_ON
        if (matchesFlashlightOff(normalized)) return IntentType.FLASHLIGHT_OFF

        // Battery & Device
        if (matchesBattery(normalized)) return IntentType.GET_BATTERY
        if (matchesStorage(normalized)) return IntentType.GET_STORAGE
        if (matchesTime(normalized)) return IntentType.GET_TIME
        if (matchesDate(normalized)) return IntentType.GET_DATE

        // Volume
        if (matchesVolumeUp(normalized)) return IntentType.VOLUME_UP
        if (matchesVolumeDown(normalized)) return IntentType.VOLUME_DOWN
        if (matchesSetVolume(normalized)) return IntentType.SET_VOLUME

        // Navigation
        if (matchesNavigation(normalized)) return IntentType.NAVIGATE
        if (matchesCurrentLocation(normalized)) return IntentType.CURRENT_LOCATION

        // Alarms & Timers
        if (matchesSetAlarm(normalized)) return IntentType.SET_ALARM
        if (matchesSetTimer(normalized)) return IntentType.SET_TIMER
        if (matchesSetReminder(normalized)) return IntentType.SET_REMINDER
        if (matchesCancelAlarm(normalized)) return IntentType.CANCEL_ALARM
        if (matchesReadReminders(normalized)) return IntentType.READ_REMINDERS

        // Camera / Vision
        if (matchesCameraDescription(normalized)) return IntentType.CAMERA_DESCRIPTION
        if (matchesOCR(normalized)) return IntentType.OCR

        // Translation
        if (matchesTranslation(normalized)) return IntentType.TRANSLATE

        // YouTube
        if (matchesYouTubeSearch(normalized)) return IntentType.SEARCH_YOUTUBE
        if (matchesYouTubePlay(normalized)) return IntentType.PLAY_YOUTUBE

        // Media controls
        if (matchesPlayMedia(normalized)) return IntentType.PLAY_MEDIA
        if (matchesPauseMedia(normalized)) return IntentType.PAUSE_MEDIA
        if (matchesResumeMedia(normalized)) return IntentType.RESUME_MEDIA
        if (matchesNextMedia(normalized)) return IntentType.NEXT_MEDIA

        // WhatsApp
        if (matchesSendWhatsApp(normalized)) return IntentType.SEND_WHATSAPP
        if (matchesReadWhatsApp(normalized)) return IntentType.READ_WHATSAPP

        // SMS
        if (matchesSendSMS(normalized)) return IntentType.SEND_SMS
        if (matchesReadSMS(normalized)) return IntentType.READ_SMS

        // Calls
        if (matchesCall(normalized, original)) return IntentType.CALL_CONTACT
        if (matchesDialNumber(normalized, original)) return IntentType.CALL_NUMBER

        // Notifications
        if (matchesReadNotification(normalized)) return IntentType.READ_NOTIFICATION

        // Screen reading
        if (matchesReadScreen(normalized)) return IntentType.READ_SCREEN

        // UI Interaction
        if (matchesClickElement(normalized)) return IntentType.CLICK_ELEMENT
        if (matchesTypeText(normalized)) return IntentType.TYPE_TEXT
        if (matchesScroll(normalized)) return IntentType.SCROLL
        if (matchesGoBack(normalized)) return IntentType.GO_BACK
        if (matchesGoHome(normalized)) return IntentType.GO_HOME
        if (matchesRecentApps(normalized)) return IntentType.RECENT_APPS

        // Open App
        if (matchesOpenApp(normalized)) return IntentType.OPEN_APP

        // Settings
        if (matchesOpenSettings(normalized)) return IntentType.OPEN_SETTINGS

        // Web Search
        if (matchesWebSearch(normalized)) return IntentType.SEARCH_WEB

        return IntentType.GENERAL_AI
    }

    // ===== MATCHING FUNCTIONS =====

    private fun matchesEmergency(text: String) =
        anyMatch(text, listOf("emergency", "sos", "help me", "help", "madad", "bachao", "بچاؤ", "مدد"))

    private fun matchesFlashlightOn(text: String) =
        anyMatch(text, listOf("flashlight on", "torch on", "turn on flashlight", "turn on torch", "torch jala", "torch on karo", "flashlight chalu"))

    private fun matchesFlashlightOff(text: String) =
        anyMatch(text, listOf("flashlight off", "torch off", "turn off flashlight", "turn off torch", "torch bujha", "torch off karo", "flashlight band"))

    private fun matchesBattery(text: String) =
        anyMatch(text, listOf("battery", "charge", "kitna charge", "battery kitni", "battery percentage", "how much battery"))

    private fun matchesStorage(text: String) =
        anyMatch(text, listOf("storage", "memory", "space", "how much storage", "kitni jagah"))

    private fun matchesTime(text: String) =
        anyMatch(text, listOf("what time", "kitne baje", "time kya hai", "current time", "what's the time"))

    private fun matchesDate(text: String) =
        anyMatch(text, listOf("what date", "today date", "aaj kaun sa din", "aaj kya tarikh", "what day is it", "today's date"))

    private fun matchesVolumeUp(text: String) =
        anyMatch(text, listOf("increase volume", "volume up", "volume badhao", "volume tez", "louder"))

    private fun matchesVolumeDown(text: String) =
        anyMatch(text, listOf("decrease volume", "volume down", "volume kam karo", "volume kam", "quieter"))

    private fun matchesSetVolume(text: String) =
        anyMatch(text, listOf("set volume", "volume to", "volume set"))

    private fun matchesNavigation(text: String) =
        anyMatch(text, listOf("navigate", "take me", "directions to", "route to", "mujhe le chalo", "rasta dikhao", "find nearest", "search place"))

    private fun matchesCurrentLocation(text: String) =
        anyMatch(text, listOf("where am i", "my location", "current location", "main kahan hoon", "meri location"))

    private fun matchesSetAlarm(text: String) =
        anyMatch(text, listOf("set alarm", "alarm laga", "alarm set", "wake me", "alarm for"))

    private fun matchesSetTimer(text: String) =
        anyMatch(text, listOf("set timer", "timer laga", "timer for", "timer set", "start timer"))

    private fun matchesSetReminder(text: String) =
        anyMatch(text, listOf("remind me", "reminder set", "yaad dilao", "reminder"))

    private fun matchesCancelAlarm(text: String) =
        anyMatch(text, listOf("cancel alarm", "alarm band", "alarm hata", "delete alarm", "stop alarm"))

    private fun matchesReadReminders(text: String) =
        anyMatch(text, listOf("read reminders", "my reminders", "mere reminder", "reminder padho"))

    private fun matchesCameraDescription(text: String) =
        anyMatch(text, listOf("what is in front", "what do you see", "describe", "what is this", "camera", "dekh", "samne kya hai", "mere saamne", "room describe"))

    private fun matchesOCR(text: String) =
        anyMatch(text, listOf("read this", "read the text", "read document", "padho", "ye padho", "text read", "read this document"))

    private fun matchesTranslation(text: String) =
        anyMatch(text, listOf("translate", "translation", "anuvad", "ترجمہ", "translate to"))

    private fun matchesYouTubeSearch(text: String) =
        anyMatch(text, listOf("youtube search", "search youtube", "youtube pe search", "search on youtube", "youtube par"))

    private fun matchesYouTubePlay(text: String) =
        anyMatch(text, listOf("play youtube", "play on youtube", "youtube pe play"))

    private fun matchesPlayMedia(text: String) =
        anyMatch(text, listOf("play", "play music", "play song", "baja"))

    private fun matchesPauseMedia(text: String) =
        anyMatch(text, listOf("pause", "ruk", "rok do", "pause karo", "stop music"))

    private fun matchesResumeMedia(text: String) =
        anyMatch(text, listOf("resume", "play again", "chalu karo", "dobara chala"))

    private fun matchesNextMedia(text: String) =
        anyMatch(text, listOf("next", "next song", "next video", "agla", "skip"))

    private fun matchesSendWhatsApp(text: String) =
        anyMatch(text, listOf("whatsapp", "whats app", "message on whatsapp", "whatsapp message", "whatsapp bhejo"))

    private fun matchesReadWhatsApp(text: String) =
        anyMatch(text, listOf("read whatsapp", "whatsapp padho", "latest whatsapp", "whatsapp message read"))

    private fun matchesSendSMS(text: String) =
        anyMatch(text, listOf("send sms", "send message", "text message", "sms bhejo", "message send", "send a text"))

    private fun matchesReadSMS(text: String) =
        anyMatch(text, listOf("read sms", "read message", "sms padho", "latest sms", "unread sms", "latest message"))

    private fun matchesCall(text: String, original: String): Boolean {
        val callKeywords = listOf("call", "phone", "dial to", "ring", "kol", "phone laga", "call karo", "کال کریں")
        return anyMatch(text, callKeywords) && !text.contains("whatsapp")
    }

    private fun matchesDialNumber(text: String, original: String): Boolean {
        val hasNumber = Patterns.PHONE.matcher(original).find()
        val dialKeywords = listOf("dial", "call", "call number")
        return hasNumber && anyMatch(text, dialKeywords)
    }

    private fun matchesReadNotification(text: String) =
        anyMatch(text, listOf("notification", "notifications", "read notification", "notification padho"))

    private fun matchesReadScreen(text: String) =
        anyMatch(text, listOf("read screen", "read page", "what is on screen", "screen padho", "kya dikh raha", "what's on my screen", "read this page"))

    private fun matchesClickElement(text: String) =
        anyMatch(text, listOf("click", "tap", "press", "click on", "tap on"))

    private fun matchesTypeText(text: String) =
        anyMatch(text, listOf("type", "write", "enter", "likh", "type this"))

    private fun matchesScroll(text: String) =
        anyMatch(text, listOf("scroll", "scroll down", "scroll up", "niche jao", "upar jao", "neechay"))

    private fun matchesGoBack(text: String) =
        anyMatch(text, listOf("go back", "back", "wapas", "peechhe", "wapas jao", "واپس"))

    private fun matchesGoHome(text: String) =
        anyMatch(text, listOf("go home", "home screen", "home page"))

    private fun matchesRecentApps(text: String) =
        anyMatch(text, listOf("recent apps", "recent", "switch app", "app switcher", "open recent"))

    private fun matchesOpenApp(text: String): Boolean {
        val openKeywords = listOf("open", "launch", "start", "chalu karo", "kholo", "چالو", "چلو")
        return anyMatch(text, openKeywords)
    }

    private fun matchesOpenSettings(text: String) =
        anyMatch(text, listOf("settings", "open settings", "go to settings", "settings kholo", "setings mein jao"))

    private fun matchesWebSearch(text: String) =
        anyMatch(text, listOf("search for", "google", "search web", "dhundo", "search karo", "talaash"))

    // ===== ENTITY EXTRACTION =====

    private fun extractPerson(text: String, original: String): String? {
        val personPatterns = listOf(
            Regex("(?:call|message|whatsapp|sms|send|text|phone)\\s+(?:to\\s+)?(.+?)(?:\\s+and|\\s+saying|\\s+on|\\s+about|\\s+that|\\.|$)", RegexOption.IGNORE_CASE),
            Regex("(?:for|to)\\s+(.+?)(?:\\s+and|\\s+saying|\\s+about|\\.|$)", RegexOption.IGNORE_CASE)
        )
        for (pattern in personPatterns) {
            val match = pattern.find(original)
            if (match != null) {
                val person = match.groupValues[1].trim()
                if (person.isNotBlank() && person.length < 50) {
                    return person.removePrefix("to ").removePrefix("for ").trim()
                }
            }
        }
        return null
    }

    private fun extractPhoneNumber(text: String): String? {
        val phonePattern = Regex("(\\+?[0-9][0-9\\s\\-()]{7,})")
        val match = phonePattern.find(text)
        return match?.groupValues?.get(1)?.replace(Regex("[\\s\\-()]"), "")
    }

    private fun extractAppName(text: String): String? {
        val appPattern = Regex("(?:open|launch|start)\\s+(.+?)(?:\\s+and|\\s+and\\s+search|\\.|$)", RegexOption.IGNORE_CASE)
        val match = appPattern.find(text)
        if (match != null) {
            val name = match.groupValues[1].trim()
            if (name.isNotBlank()) return name
        }
        // Check for known apps
        for (app in KNOWN_APPS) {
            if (text.contains(app.lowercase())) return app
        }
        return null
    }

    private fun extractMessage(text: String, original: String): String? {
        val msgPatterns = listOf(
            Regex("(?:saying|message saying|text|saying that|saying)\\s+(.+?)(?:\\s*\\.?$)", RegexOption.IGNORE_CASE),
            Regex("(?:message|sms|text)\\s+(?:to\\s+)?\\w+\\s+(?:saying|that)\\s+(.+?)(?:\\s*\\.?$)", RegexOption.IGNORE_CASE)
        )
        for (pattern in msgPatterns) {
            val match = pattern.find(original)
            if (match != null) {
                val msg = match.groupValues[1].trim()
                if (msg.isNotBlank()) return msg
            }
        }
        return null
    }

    private fun extractTime(text: String, original: String): String? {
        val timePatterns = listOf(
            Regex("(\\d{1,2}\\s*(?:am|pm|a\\.m\\.|p\\.m\\.))", RegexOption.IGNORE_CASE),
            Regex("(\\d{1,2}\\s*:\\s*\\d{2})", RegexOption.IGNORE_CASE),
            Regex("(\\d+)\\s*(?:minute|min|hour|second)", RegexOption.IGNORE_CASE)
        )
        for (pattern in timePatterns) {
            val match = pattern.find(original)
            if (match != null) return match.groupValues[1].trim()
        }
        return null
    }

    private fun extractDate(text: String, original: String): String? {
        val datePatterns = listOf(
            Regex("(?:tomorrow|today|day after|yesterday|next)\\s*(?:at)?\\s*", RegexOption.IGNORE_CASE),
            Regex("\\d{1,2}/\\d{1,2}/\\d{2,4}")
        )
        for (pattern in datePatterns) {
            val match = pattern.find(original)
            if (match != null) return match.value.trim()
        }
        if (anyMatch(text, listOf("tomorrow", "kal", "آج"))) return "tomorrow"
        if (anyMatch(text, listOf("today", "aaj", "آج"))) return "today"
        return null
    }

    private fun extractLocation(text: String, original: String): String? {
        val locPatterns = listOf(
            Regex("(?:to|towards|near|at)\\s+(.+?)(?:\\s+and|\\s*\\.?$)", RegexOption.IGNORE_CASE),
            Regex("(?:nearest|closest)\\s+(.+?)(?:\\s+and|\\s*\\.?$)", RegexOption.IGNORE_CASE)
        )
        for (pattern in locPatterns) {
            val match = pattern.find(original)
            if (match != null) {
                val loc = match.groupValues[1].trim()
                if (loc.isNotBlank() && loc.length < 100) return loc
            }
        }
        return null
    }

    private fun extractSearchQuery(text: String, original: String): String? {
        val searchPatterns = listOf(
            Regex("(?:search|find|google)\\s+(?:for\\s+)?(.+?)(?:\\s*\\.?$)", RegexOption.IGNORE_CASE),
            Regex("(?:youtube|search).*?(?:for|of|about)\\s+(.+?)(?:\\s*\\.?$)", RegexOption.IGNORE_CASE)
        )
        for (pattern in searchPatterns) {
            val match = pattern.find(original)
            if (match != null) {
                val query = match.groupValues[1].trim()
                if (query.isNotBlank() && query.length < 200) return query
            }
        }
        return null
    }

    private fun extractUIElement(text: String, original: String): String? {
        val uiPatterns = listOf(
            Regex("(?:click|tap|press)\\s+(?:on\\s+)?(.+?)(?:\\s*\\.?$)", RegexOption.IGNORE_CASE),
            Regex("(?:read|find)\\s+(?:the\\s+)?(.+?)(?:\\s+button|\\s+link|\\s+text|\\s*\\.?$)", RegexOption.IGNORE_CASE)
        )
        for (pattern in uiPatterns) {
            val match = pattern.find(original)
            if (match != null) {
                val element = match.groupValues[1].trim()
                if (element.isNotBlank() && element.length < 100) return element
            }
        }
        return null
    }

    private fun calculateConfidence(text: String, intent: IntentType): Float {
        return when (intent) {
            IntentType.UNKNOWN -> 0f
            IntentType.GENERAL_AI -> 0.5f
            else -> 0.85f
        }
    }

    private fun anyMatch(text: String, keywords: List<String>): Boolean {
        return keywords.any { text.contains(it, ignoreCase = true) }
    }

    companion object {
        private val SENSITIVE_INTENTS = setOf(
            IntentType.SEND_SMS,
            IntentType.SEND_WHATSAPP,
            IntentType.CALL_NUMBER,
            IntentType.EMERGENCY,
            IntentType.CALL_CONTACT
        )

        private val ROMAN_HINDI_INDICATORS = listOf(
            "karo", "kholo", "bhejo", "lagao", "baja", "padho", "dhundo",
            "kya hai", "kitna", "kitne", "kab", "kahan", "kaise",
            "chalu", "band", "badhao", "kam karo", "lagao", "bhejna",
            "mera", "meri", "mere", "hain", "hai", "ko", "se", "mein",
            "aao", "jao", "do", "de", "lo"
        )

        private val KNOWN_APPS = listOf(
            "YouTube", "WhatsApp", "Chrome", "Instagram", "Facebook", "Twitter",
            "Telegram", "Gmail", "Maps", "Google Maps", "Settings", "Camera",
            "Phone", "Messages", "Clock", "Calendar", "Calculator", "Gallery",
            "Play Store", "Files", "Spotify", "Netflix", "Amazon", "Flipkart",
            "PhonePe", "Google Pay", "Paytm", "Swiggy", "Zomato", "Uber", "Ola"
        )
    }
}
