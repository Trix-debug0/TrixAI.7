package com.trixai.assistant.ai

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.Content
import com.google.ai.client.generativeai.type.GenerateContentResponse
import com.google.ai.client.generativeai.type.generationConfig
import com.trixai.assistant.util.PreferenceManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class AIEngine(private val preferenceManager: PreferenceManager) {

    private var generativeModel: GenerativeModel? = null
    private var apiKey: String? = null

    private val systemInstruction = """
You are Trix AI, a professional voice assistant designed primarily for blind and visually impaired Android users.

Your core principles:
- Be concise and clear in responses (they will be spoken aloud)
- Always describe what you are doing or what happened
- Be helpful and proactive
- Communicate uncertainty honestly
- Never pretend an action succeeded if it failed
- Use simple, natural language

Response guidelines:
- Keep responses under 3 sentences when possible
- Avoid visual descriptions that require sight (use "I found" not "I see")
- Read back important information clearly
- For navigation results, give step-by-step directions
- For error states, explain what happened and suggest alternatives

You understand English, Hindi (including Hinglish), and Urdu. Respond in the same language the user speaks in.
""".trimIndent()

    fun initialize(apiKey: String) {
        this.apiKey = apiKey
        try {
            val config = generationConfig {
                temperature = 0.7f
                topK = 40
                topP = 0.95f
                maxOutputTokens = 500
            }
            generativeModel = GenerativeModel(
                modelName = "gemini-1.5-flash",
                apiKey = apiKey,
                generationConfig = config,
                systemInstruction = Content { text(systemInstruction) }
            )
        } catch (e: Exception) {
            generativeModel = null
        }
    }

    suspend fun generateResponse(
        userMessage: String,
        context: ConversationContext? = null
    ): String {
        val model = generativeModel ?: return getOfflineResponse(userMessage)

        return try {
            val history = context?.toHistory() ?: emptyList()
            val chat = generativeModel!!.startChat(history)
            val response = chat.sendMessage(userMessage)
            response.text ?: "I'm sorry, I couldn't process that."
        } catch (e: Exception) {
            getOfflineResponse(userMessage)
        }
    }

    private fun getOfflineResponse(input: String): String {
        val lower = input.lowercase()
        return when {
            anyOf(lower, "hello", "hi", "hey", "namaste", "salam") ->
                "Hello! I'm Trix AI. How can I help you?"
            anyOf(lower, "thank", "shukriya", "dhanyavad") ->
                "You're welcome! Is there anything else I can help with?"
            anyOf(lower, "battery") ->
                "Please wait while I check your battery level."
            anyOf(lower, "time") ->
                "Let me check the current time for you."
            else ->
                "I'm currently offline. Some features require an internet connection. Please check your connection and try again."
        }
    }

    private fun anyOf(text: String, vararg keywords: String) =
        keywords.any { text.contains(it) }

    fun isInitialized(): Boolean = generativeModel != null
}

data class ConversationContext(
    val history: List<MessagePair> = emptyList(),
    val lastIntent: ParsedIntent? = null
) {
    fun toHistory(): List<Content> {
        return history.flatMap { pair ->
            listOf(
                Content("user") { text(pair.user) },
                Content("model") { text(pair.assistant) }
            )
        }
    }
}

data class MessagePair(val user: String, val assistant: String)
