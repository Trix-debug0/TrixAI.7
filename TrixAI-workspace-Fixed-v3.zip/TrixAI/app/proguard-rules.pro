# Trix AI ProGuard Rules

# Keep AI engine
-keep class com.google.ai.client.generativeai.** { *; }

# Keep ML Kit
-keep class com.google.mlkit.** { *; }

# Keep data classes
-keep class com.trixai.assistant.ai.** { *; }
-keep class com.trixai.assistant.voice.** { *; }

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# General Android
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}
