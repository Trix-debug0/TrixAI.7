# Trix AI

**Your Voice. Your Phone. Your Freedom.**

Trix AI is a professional, production-ready Android voice assistant designed primarily for blind and visually impaired users. The application enables natural voice control of common phone functions with support for English, Hindi (including Hinglish), and Urdu.

---

## Features

### Voice-First Interface
- Large, accessible microphone button with haptic feedback
- Status indicators: Ready, Listening, Thinking, Working, Done
- Full TalkBack support and accessibility labels
- Black & White high-contrast design

### Natural Language Understanding
- No fixed commands — speak naturally
- Understands English, Hindi, Urdu, and Hinglish
- Automatic language detection or manual selection
- Context-aware conversation memory

### Phone Control
- Open applications
- Make calls and send messages
- Control WhatsApp and SMS
- Navigate with Google Maps
- Read notifications, screens, and text
- Set alarms, timers, and reminders
- Control volume, flashlight, and settings
- Camera vision and OCR text reading

### Activation Methods
1. Large microphone button
2. Floating overlay button (from any app)
3. Accessibility shortcut
4. Quick Settings tile
5. Notification action
6. Wake word: "Hey Trix"
7. Headset/Bluetooth button
8. Hardware button shortcut (where supported)

### Background Operation
- Foreground service for persistent operation
- Battery-optimized architecture
- Ongoing notification with controls

### Safety & Privacy
- Confirmation before sensitive actions (messages, calls)
- Duplicate action prevention
- No data collected without consent
- Granular permission controls
- Privacy dashboard

---

## Architecture

```
com.trixai.assistant/
├── TrixAIApplication.kt          # Application class
├── ai/
│   ├── IntentModel.kt            # Intent types and data models
│   ├── IntentParser.kt           # NLP intent parsing engine
│   └── AIEngine.kt              # Gemini AI integration
├── voice/
│   └── VoiceManager.kt           # Speech recognition & TTS
├── actions/
│   └── ActionExecutor.kt         # Action execution engine
├── service/
│   ├── TrixAccessibilityService.kt  # Accessibility Service
│   ├── TrixForegroundService.kt     # Background service
│   ├── OverlayService.kt            # Floating overlay
│   ├── TrixQuickSettingsTile.kt     # Quick Settings tile
│   └── BootReceiver.kt             # Boot receiver
├── notification/
│   └── TrixNotificationListener.kt  # Notification listener
├── vision/
│   ├── CameraVision.kt           # Camera analysis
│   └── TextExtractor.kt          # OCR text extraction
├── device/
│   └── DeviceInfo.kt             # Device information
├── ui/
│   ├── splash/SplashActivity.kt  # Splash screen
│   ├── main/MainActivity.kt      # Main interface
│   ├── onboarding/OnboardingActivity.kt  # Setup wizard
│   ├── settings/SettingsActivity.kt      # Settings
│   └── overlay/                   # Overlay UI
├── viewmodel/
│   └── MainViewModel.kt          # Main view model
└── util/
    ├── PreferenceManager.kt      # DataStore preferences
    └── Utils.kt                  # Utility functions
```

---

## Build & Run

### Requirements
- Android Studio Hedgehog or later
- JDK 17
- Android SDK 34
- Minimum SDK 26 (Android 8.0)

### Setup
1. Open the project in Android Studio
2. Sync Gradle dependencies
3. (Optional) Add your Gemini API key for AI conversation features
4. Build and run on a physical device (recommended for accessibility testing)

### Permissions Required
- Microphone (voice commands)
- Camera (vision/OCR)
- Contacts (calling/messaging)
- Phone (making calls)
- SMS (sending messages)
- Location (navigation)
- Notifications (reading notifications)
- Accessibility Service (screen reading, UI interaction)
- Display Over Other Apps (floating button)

---

## Configuration

### Gemini API Key (Optional)
For AI conversation features, add your API key in `local.properties`:
```
GEMINI_API_KEY=your_api_key_here
```

### Build Variants
- **Debug**: No minification, verbose logging
- **Release**: Full minification and resource shrinking

---

## Design Principles

1. **Accessibility First** — Every element has proper labels and large touch targets
2. **Monochrome Design** — Black background, white text, professional appearance
3. **Voice-Operable** — Complete operation through voice with minimal screen interaction
4. **Privacy-Centric** — No data collection, explicit permissions, clear consent
5. **Reliable** — Error handling, duplicate prevention, crash recovery
6. **Battery-Efficient** — Event-driven architecture, minimal background processing

---

## License

Proprietary — All rights reserved.

---

*Trix AI — Your Voice. Your Phone. Your Freedom.*
