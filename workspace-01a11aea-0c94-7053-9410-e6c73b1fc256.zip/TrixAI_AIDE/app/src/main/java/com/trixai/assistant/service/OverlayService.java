package com.trixai.assistant.service;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.trixai.assistant.R;
import com.trixai.assistant.ui.MainActivity;

public class OverlayService extends Service {
    
    public static final String ACTION_SHOW = "com.trixai.assistant.overlay.SHOW";
    public static final String ACTION_HIDE = "com.trixai.assistant.overlay.HIDE";
    
    private WindowManager windowManager;
    private FrameLayout overlayView;
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_SHOW.equals(action)) {
                showOverlay();
            } else if (ACTION_HIDE.equals(action)) {
                hideOverlay();
            }
        }
        return START_STICKY;
    }
    
    @SuppressLint("ClickableViewAccessibility")
    private void showOverlay() {
        if (overlayView != null) return;
        
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager == null) return;
        
        int type;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            type = WindowManager.LayoutParams.TYPE_PHONE;
        }
        
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            150, 150,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 300;
        
        overlayView = new FrameLayout(this);
        ImageView micIcon = new ImageView(this);
        micIcon.setImageResource(R.drawable.ic_mic_white);
        micIcon.setBackgroundResource(R.drawable.overlay_button_bg);
        micIcon.setContentDescription("Trix AI - Tap to speak");
        micIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        micIcon.setPadding(24, 24, 24, 24);
        overlayView.addView(micIcon, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        
        final int[] initialXY = new int[2];
        final float[] initialTouchXY = new float[2];
        final boolean[] moved = {false};
        
        overlayView.setOnTouchListener(new android.view.View.OnTouchListener() {
            @Override
            public boolean onTouch(android.view.View v, MotionEvent event) {
                if (windowManager == null || overlayView == null) return false;
                
                try {
                    WindowManager.LayoutParams p = (WindowManager.LayoutParams) overlayView.getLayoutParams();
                    if (p == null) return false;
                    
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialXY[0] = p.x;
                            initialXY[1] = p.y;
                            initialTouchXY[0] = event.getRawX();
                            initialTouchXY[1] = event.getRawY();
                            moved[0] = false;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            int dx = (int)(event.getRawX() - initialTouchXY[0]);
                            int dy = (int)(event.getRawY() - initialTouchXY[1]);
                            if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
                                moved[0] = true;
                            }
                            p.x = initialXY[0] + dx;
                            p.y = initialXY[1] + dy;
                            windowManager.updateViewLayout(overlayView, p);
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (!moved[0]) {
                                // Tap detected - open main activity with voice trigger
                                Intent tapIntent = new Intent(OverlayService.this, MainActivity.class);
                                tapIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                tapIntent.putExtra("TRIGGER_VOICE", true);
                                startActivity(tapIntent);
                            }
                            return true;
                    }
                } catch (Exception e) {
                    // Window might have been removed
                }
                return false;
            }
        });
        
        try {
            windowManager.addView(overlayView, params);
        } catch (Exception e) {
            overlayView = null;
        }
    }
    
    private void hideOverlay() {
        if (overlayView != null && windowManager != null) {
            try {
                windowManager.removeView(overlayView);
            } catch (Exception e) {
                // View might already be removed
            }
            overlayView = null;
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        hideOverlay();
    }
}
