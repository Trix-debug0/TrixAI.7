package com.trixai.assistant.actions;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraAccessException;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.util.Log;

import com.trixai.assistant.util.Utils;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Executes parsed voice commands using Android APIs.
 * Handles duplicate prevention and safety confirmations.
 */
public class ActionExecutor {
    
    private static final String TAG = "ActionExecutor";
    private Context context;
    private ActionCallback callback;
    private ConcurrentHashMap<String, Long> completedActions = new ConcurrentHashMap<>();
    
    public interface ActionCallback {
        void onActionStarted(IntentParser.ParsedCommand cmd);
        void onActionCompleted(IntentParser.ParsedCommand cmd, String message);
        void onActionFailed(IntentParser.ParsedCommand cmd, String message);
        void onConfirmationRequired(IntentParser.ParsedCommand cmd, String message);
    }
    
    public ActionExecutor(Context context) {
        this.context = context;
    }
    
    public void setCallback(ActionCallback callback) {
        this.callback = callback;
    }
    
    public void execute(IntentParser.ParsedCommand cmd) {
        String actionId = generateActionId(cmd);
        
        // Duplicate check
        if (isDuplicate(actionId)) {
            if (callback != null) {
                callback.onActionFailed(cmd, "This action was just performed. Skipping to prevent duplicates.");
            }
            return;
        }
        
        // Confirmation check
        if (IntentParser.requiresConfirmation(cmd.intent)) {
            String confirmMsg = getConfirmationMessage(cmd);
            if (callback != null) {
                callback.onConfirmationRequired(cmd, confirmMsg);
            }
            return;
        }
        
        performAction(cmd);
    }
    
    public void confirmAndExecute(IntentParser.ParsedCommand cmd) {
        performAction(cmd);
    }
    
    private void performAction(IntentParser.ParsedCommand cmd) {
        if (callback != null) callback.onActionStarted(cmd);
        
        try {
            switch (cmd.intent) {
                case IntentParser.INTENT_OPEN_APP:
                    openApp(cmd);
                    break;
                case IntentParser.INTENT_CALL_CONTACT:
                    callContact(cmd);
                    break;
                case IntentParser.INTENT_CALL_NUMBER:
                    callNumber(cmd);
                    break;
                case IntentParser.INTENT_SEND_WHATSAPP:
                    sendWhatsApp(cmd);
                    break;
                case IntentParser.INTENT_SEND_SMS:
                    sendSMS(cmd);
                    break;
                case IntentParser.INTENT_SEARCH_WEB:
                    searchWeb(cmd);
                    break;
                case IntentParser.INTENT_SEARCH_YOUTUBE:
                    searchYouTube(cmd);
                    break;
                case IntentParser.INTENT_SET_ALARM:
                    setAlarm(cmd);
                    break;
                case IntentParser.INTENT_SET_TIMER:
                    setTimer(cmd);
                    break;
                case IntentParser.INTENT_GET_BATTERY:
                    getBattery(cmd);
                    break;
                case IntentParser.INTENT_GET_TIME:
                    getTime(cmd);
                    break;
                case IntentParser.INTENT_GET_DATE:
                    getDate(cmd);
                    break;
                case IntentParser.INTENT_FLASHLIGHT_ON:
                    toggleFlashlight(cmd, true);
                    break;
                case IntentParser.INTENT_FLASHLIGHT_OFF:
                    toggleFlashlight(cmd, false);
                    break;
                case IntentParser.INTENT_GET_STORAGE:
                    getStorage(cmd);
                    break;
                case IntentParser.INTENT_VOLUME_UP:
                    adjustVolume(cmd, true);
                    break;
                case IntentParser.INTENT_VOLUME_DOWN:
                    adjustVolume(cmd, false);
                    break;
                case IntentParser.INTENT_NAVIGATE:
                    navigate(cmd);
                    break;
                case IntentParser.INTENT_OPEN_SETTINGS:
                    openSettings(cmd);
                    break;
                case IntentParser.INTENT_GO_BACK:
                case IntentParser.INTENT_GO_HOME:
                case IntentParser.INTENT_SCROLL:
                case IntentParser.INTENT_READ_SCREEN:
                case IntentParser.INTENT_READ_NOTIFICATIONS:
                case IntentParser.INTENT_READ_SMS:
                case IntentParser.INTENT_PLAY_MEDIA:
                case IntentParser.INTENT_PAUSE_MEDIA:
                case IntentParser.INTENT_NEXT_MEDIA:
                    // These require accessibility service - handled by MainActivity
                    if (callback != null) callback.onActionCompleted(cmd, "");
                    break;
                case IntentParser.INTENT_GENERAL_AI:
                    // Handled by AI engine
                    if (callback != null) callback.onActionCompleted(cmd, "");
                    break;
                default:
                    failAction(cmd, "I'm not sure what you'd like me to do. Can you please rephrase that?");
            }
        } catch (Exception e) {
            Log.e(TAG, "Action failed", e);
            failAction(cmd, "I couldn't complete that action. Please try again.");
        }
    }
    
    // ===== Action Implementations =====
    
    private void openApp(IntentParser.ParsedCommand cmd) {
        if (cmd.appName == null) {
            failAction(cmd, "Which app would you like me to open?");
            return;
        }
        
        String packageName = Utils.findInstalledApp(context, cmd.appName);
        if (packageName == null) {
            packageName = getKnownPackageName(cmd.appName);
        }
        
        if (packageName != null) {
            Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                completeAction(cmd, "Opening " + cmd.appName + ".");
            } else {
                failAction(cmd, cmd.appName + " is not installed on this device.");
            }
        } else {
            failAction(cmd, "I couldn't find " + cmd.appName + " on your device.");
        }
    }
    
    private void callContact(IntentParser.ParsedCommand cmd) {
        if (cmd.person == null) {
            failAction(cmd, "Who would you like me to call?");
            return;
        }
        
        Uri contactUri = Uri.withAppendedPath(
            ContactsContract.Contacts.CONTENT_FILTER_URI,
            Uri.encode(cmd.person)
        );
        
        android.database.Cursor cursor = null;
        android.database.Cursor phones = null;
        String number = null;
        
        try {
            cursor = context.getContentResolver().query(
                contactUri,
                new String[]{ContactsContract.Contacts._ID, ContactsContract.Contacts.HAS_PHONE_NUMBER},
                null, null, null
            );
            
            if (cursor == null || !cursor.moveToFirst()) {
                failAction(cmd, "I couldn't find a contact named " + cmd.person + ".");
                return;
            }
            
            if (cursor.getInt(1) != 1) {
                failAction(cmd, cmd.person + " doesn't have a phone number.");
                return;
            }
            
            String contactId = cursor.getString(0);
            phones = context.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER, 
                             ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME},
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                new String[]{contactId},
                null
            );
            
            if (phones == null || !phones.moveToFirst()) {
                failAction(cmd, "I couldn't find a phone number for " + cmd.person + ".");
                return;
            }
            
            number = phones.getString(0);
            
            // Start the call first, then report success
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + number));
            callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(callIntent);
            completeAction(cmd, "Calling " + cmd.person + ".");
            
        } catch (SecurityException e) {
            // Fallback to dialer app
            if (number != null) {
                try {
                    Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                    dialIntent.setData(Uri.parse("tel:" + number));
                    dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(dialIntent);
                    completeAction(cmd, "Opening dialer for " + cmd.person + ". Grant phone permission for direct calling.");
                } catch (Exception ex) {
                    failAction(cmd, "I need phone permission. Please grant it in settings.");
                }
            } else {
                failAction(cmd, "I need phone permission to make calls. Please grant it in settings.");
            }
        } catch (Exception e) {
            failAction(cmd, "I couldn't call " + cmd.person + ". Please try again.");
        } finally {
            if (phones != null) phones.close();
            if (cursor != null) cursor.close();
        }
    }
    
    private void callNumber(IntentParser.ParsedCommand cmd) {
        if (cmd.phoneNumber == null) {
            failAction(cmd, "Please say the phone number.");
            return;
        }
        
        try {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + cmd.phoneNumber));
            callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(callIntent);
            completeAction(cmd, "Calling " + formatPhoneNumber(cmd.phoneNumber) + ".");
        } catch (SecurityException e) {
            // Fallback to dialer
            try {
                Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                dialIntent.setData(Uri.parse("tel:" + cmd.phoneNumber));
                dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(dialIntent);
                completeAction(cmd, "Opening dialer for " + formatPhoneNumber(cmd.phoneNumber) + ".");
            } catch (Exception ex) {
                failAction(cmd, "I couldn't make the call. Please grant phone permission in settings.");
            }
        } catch (Exception e) {
            failAction(cmd, "I couldn't make the call.");
        }
    }
    
    private String formatPhoneNumber(String number) {
        if (number == null || number.length() < 4) return number;
        // For spoken output, break into chunks
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < number.length(); i++) {
            if (i > 0 && i % 2 == 0) sb.append(" ");
            sb.append(number.charAt(i));
        }
        return sb.toString();
    }
    
    private void sendWhatsApp(IntentParser.ParsedCommand cmd) {
        if (cmd.person == null) {
            failAction(cmd, "Who should I send the WhatsApp message to?");
            return;
        }
        if (cmd.message == null) {
            failAction(cmd, "What message would you like to send?");
            return;
        }
        
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.setPackage("com.whatsapp");
            intent.putExtra(Intent.EXTRA_TEXT, cmd.message);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            completeAction(cmd, "Opening WhatsApp with your message.");
        } catch (Exception e) {
            failAction(cmd, "WhatsApp is not installed on this device.");
        }
    }
    
    private void sendSMS(IntentParser.ParsedCommand cmd) {
        String recipient = cmd.person != null ? cmd.person : cmd.phoneNumber;
        if (recipient == null) {
            failAction(cmd, "Who should I send the message to?");
            return;
        }
        if (cmd.message == null) {
            failAction(cmd, "What message would you like to send?");
            return;
        }
        
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
        smsIntent.setData(Uri.parse("smsto:" + recipient));
        smsIntent.putExtra("sms_body", cmd.message);
        smsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(smsIntent);
        completeAction(cmd, "Opening messaging app for " + recipient + ".");
    }
    
    private void searchWeb(IntentParser.ParsedCommand cmd) {
        if (cmd.searchQuery == null) {
            failAction(cmd, "What would you like me to search for?");
            return;
        }
        
        Intent searchIntent = new Intent(Intent.ACTION_WEB_SEARCH);
        searchIntent.putExtra(android.app.SearchManager.QUERY, cmd.searchQuery);
        searchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(searchIntent);
        completeAction(cmd, "Searching for " + cmd.searchQuery + ".");
    }
    
    private void searchYouTube(IntentParser.ParsedCommand cmd) {
        if (cmd.searchQuery == null) {
            failAction(cmd, "What would you like to search on YouTube?");
            return;
        }
        
        Intent ytIntent = new Intent(Intent.ACTION_SEARCH);
        ytIntent.setPackage("com.google.android.youtube");
        ytIntent.putExtra(android.app.SearchManager.QUERY, cmd.searchQuery);
        ytIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        
        try {
            context.startActivity(ytIntent);
            completeAction(cmd, "Searching YouTube for " + cmd.searchQuery + ".");
        } catch (Exception e) {
            Intent webIntent = new Intent(Intent.ACTION_VIEW);
            webIntent.setData(Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(cmd.searchQuery)));
            webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(webIntent);
            completeAction(cmd, "Opening YouTube search for " + cmd.searchQuery + ".");
        }
    }
    
    private void setAlarm(IntentParser.ParsedCommand cmd) {
        Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
        alarmIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (cmd.time != null) {
            alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Alarm");
        }
        
        try {
            context.startActivity(alarmIntent);
            completeAction(cmd, "Opening alarm settings." + (cmd.time != null ? " Set for " + cmd.time + "." : ""));
        } catch (Exception e) {
            failAction(cmd, "I couldn't open alarm settings.");
        }
    }
    
    private void setTimer(IntentParser.ParsedCommand cmd) {
        if (cmd.time == null) {
            failAction(cmd, "How long should the timer be?");
            return;
        }
        
        Intent timerIntent = new Intent(AlarmClock.ACTION_SET_TIMER);
        timerIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        
        try {
            context.startActivity(timerIntent);
            completeAction(cmd, "Setting timer for " + cmd.time + ".");
        } catch (Exception e) {
            failAction(cmd, "I couldn't set the timer.");
        }
    }
    
    private void getBattery(IntentParser.ParsedCommand cmd) {
        Intent batteryIntent = context.registerReceiver(null, 
            new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        
        if (batteryIntent == null) {
            failAction(cmd, "I couldn't read the battery level.");
            return;
        }
        
        int level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int percentage = (level >= 0 && scale > 0) ? (level * 100 / scale) : -1;
        
        if (percentage >= 0) {
            String charging = "";
            int status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            if (status == BatteryManager.BATTERY_STATUS_CHARGING || 
                status == BatteryManager.BATTERY_STATUS_FULL) {
                charging = " and charging";
            }
            completeAction(cmd, "Your battery is at " + percentage + " percent" + charging + ".");
        } else {
            failAction(cmd, "I couldn't read the battery level.");
        }
    }
    
    private void getTime(IntentParser.ParsedCommand cmd) {
        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY);
        int minute = now.get(Calendar.MINUTE);
        String amPm = (hour < 12) ? "AM" : "PM";
        int displayHour = (hour % 12 == 0) ? 12 : hour % 12;
        
        completeAction(cmd, "The current time is " + displayHour + ":" + String.format("%02d", minute) + " " + amPm + ".");
    }
    
    private void getDate(IntentParser.ParsedCommand cmd) {
        Calendar now = Calendar.getInstance();
        String dayOfWeek = now.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, java.util.Locale.getDefault());
        String month = now.getDisplayName(Calendar.MONTH, Calendar.LONG, java.util.Locale.getDefault());
        int day = now.get(Calendar.DAY_OF_MONTH);
        int year = now.get(Calendar.YEAR);
        
        completeAction(cmd, "Today is " + dayOfWeek + ", " + month + " " + day + ", " + year + ".");
    }
    
    private void adjustVolume(IntentParser.ParsedCommand cmd, boolean up) {
        try {
            AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            if (audioManager == null) {
                failAction(cmd, "I couldn't adjust the volume.");
                return;
            }
            int direction = up ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER;
            audioManager.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, direction, 
                AudioManager.FLAG_SHOW_UI);
            completeAction(cmd, up ? "Volume increased." : "Volume decreased.");
        } catch (Exception e) {
            failAction(cmd, "I couldn't adjust the volume.");
        }
    }
    
    private void navigate(IntentParser.ParsedCommand cmd) {
        if (cmd.location == null) {
            failAction(cmd, "Where would you like to go?");
            return;
        }
        
        Uri gmmIntentUri = Uri.parse("google.navigation:q=" + Uri.encode(cmd.location));
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        mapIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        
        try {
            context.startActivity(mapIntent);
            completeAction(cmd, "Starting navigation to " + cmd.location + ".");
        } catch (Exception e) {
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/" + Uri.encode(cmd.location)));
            webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(webIntent);
            completeAction(cmd, "Opening directions to " + cmd.location + ".");
        }
    }
    
    private void openSettings(IntentParser.ParsedCommand cmd) {
        Intent settingsIntent = new Intent(Settings.ACTION_SETTINGS);
        settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(settingsIntent);
        completeAction(cmd, "Opening settings.");
    }
    
    // ===== Helper Methods =====
    
    private void completeAction(IntentParser.ParsedCommand cmd, String message) {
        String actionId = generateActionId(cmd);
        completedActions.put(actionId, System.currentTimeMillis());
        if (callback != null) callback.onActionCompleted(cmd, message);
    }
    
    private void failAction(IntentParser.ParsedCommand cmd, String message) {
        if (callback != null) callback.onActionFailed(cmd, message);
    }
    
    private String generateActionId(IntentParser.ParsedCommand cmd) {
        return cmd.intent + "_" + (cmd.person != null ? cmd.person : "") + "_" + (System.currentTimeMillis() / 5000);
    }
    
    private boolean isDuplicate(String actionId) {
        long now = System.currentTimeMillis();
        // Clean old entries safely using iterator
        Iterator<Map.Entry<String, Long>> it = completedActions.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Long> entry = it.next();
            if (now - entry.getValue() > 10000) {
                it.remove();
            }
        }
        return completedActions.containsKey(actionId);
    }
    
    private String getConfirmationMessage(IntentParser.ParsedCommand cmd) {
        switch (cmd.intent) {
            case IntentParser.INTENT_SEND_SMS:
                String recipient = cmd.person != null ? cmd.person : cmd.phoneNumber;
                return "Sending SMS to " + recipient + ": '" + cmd.message + "'. Should I send it?";
            case IntentParser.INTENT_SEND_WHATSAPP:
                return "WhatsApp message to " + cmd.person + ": '" + cmd.message + "'. Send?";
            case IntentParser.INTENT_CALL_NUMBER:
                return "I'm about to call " + cmd.phoneNumber + ". Should I continue?";
            default:
                return "Please confirm this action.";
        }
    }
    
    private static final HashMap<String, String> KNOWN_APPS = new HashMap<>();
    static {
        KNOWN_APPS.put("youtube", "com.google.android.youtube");
        KNOWN_APPS.put("whatsapp", "com.whatsapp");
        KNOWN_APPS.put("chrome", "com.android.chrome");
        KNOWN_APPS.put("instagram", "com.instagram.android");
        KNOWN_APPS.put("facebook", "com.facebook.katana");
        KNOWN_APPS.put("twitter", "com.twitter.android");
        KNOWN_APPS.put("telegram", "org.telegram.messenger");
        KNOWN_APPS.put("gmail", "com.google.android.gm");
        KNOWN_APPS.put("maps", "com.google.android.apps.maps");
        KNOWN_APPS.put("google maps", "com.google.android.apps.maps");
        KNOWN_APPS.put("camera", "com.android.camera");
        KNOWN_APPS.put("settings", "com.android.settings");
        KNOWN_APPS.put("phone", "com.android.dialer");
        KNOWN_APPS.put("messages", "com.google.android.apps.messaging");
        KNOWN_APPS.put("clock", "com.android.deskclock");
        KNOWN_APPS.put("calendar", "com.google.android.calendar");
        KNOWN_APPS.put("calculator", "com.android.calculator2");
        KNOWN_APPS.put("play store", "com.android.vending");
        KNOWN_APPS.put("files", "com.android.documentsui");
        KNOWN_APPS.put("gallery", "com.google.android.apps.photos");
        KNOWN_APPS.put("spotify", "com.spotify.music");
        KNOWN_APPS.put("netflix", "com.netflix.mediaclient");
        KNOWN_APPS.put("amazon", "com.amazon.mShop.android.shopping");
        KNOWN_APPS.put("flipkart", "com.flipkart.android");
        KNOWN_APPS.put("phonepe", "com.phonepe.app");
        KNOWN_APPS.put("google pay", "com.google.android.apps.nbu.paisa.user");
        KNOWN_APPS.put("paytm", "net.one97.paytm");
        KNOWN_APPS.put("swiggy", "com.swiggy.android");
        KNOWN_APPS.put("zomato", "com.zomato.android");
        KNOWN_APPS.put("uber", "com.ubercab");
        KNOWN_APPS.put("ola", "com.olacabs.customer");
        KNOWN_APPS.put("signal", "org.thoughtcrime.securesms");
        KNOWN_APPS.put("discord", "com.discord");
        KNOWN_APPS.put("tiktok", "com.zhiliaoapp.musically");
    }
    
    private String getKnownPackageName(String appName) {
        if (appName == null) return null;
        return KNOWN_APPS.get(appName.toLowerCase().trim());
    }
    
    // ===== Flashlight =====
    
    private static boolean flashlightOn = false;
    
    private void toggleFlashlight(IntentParser.ParsedCommand cmd, boolean on) {
        try {
            CameraManager cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            if (cameraManager == null) {
                failAction(cmd, "Flashlight is not available on this device.");
                return;
            }
            
            String cameraId = cameraManager.getCameraIdList().length > 0 
                ? cameraManager.getCameraIdList()[0] : null;
            
            if (cameraId == null) {
                failAction(cmd, "No camera found for flashlight.");
                return;
            }
            
            cameraManager.setTorchMode(cameraId, on);
            flashlightOn = on;
            completeAction(cmd, on ? "Flashlight turned on." : "Flashlight turned off.");
        } catch (CameraAccessException e) {
            failAction(cmd, "I couldn't access the flashlight. Another app might be using the camera.");
        } catch (Exception e) {
            failAction(cmd, "Flashlight is not available on this device.");
        }
    }
    
    // ===== Storage =====
    
    private void getStorage(IntentParser.ParsedCommand cmd) {
        try {
            StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
            long totalBytes = stat.getTotalBytes();
            long availBytes = stat.getAvailableBytes();
            double totalGB = totalBytes / (1024.0 * 1024.0 * 1024.0);
            double availGB = availBytes / (1024.0 * 1024.0 * 1024.0);
            completeAction(cmd, String.format("You have %.1f gigabytes free out of %.1f total.", availGB, totalGB));
        } catch (Exception e) {
            failAction(cmd, "I couldn't read storage information.");
        }
    }
}
