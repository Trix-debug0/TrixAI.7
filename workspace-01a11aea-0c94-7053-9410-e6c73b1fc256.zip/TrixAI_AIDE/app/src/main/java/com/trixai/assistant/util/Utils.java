package com.trixai.assistant.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class Utils {
    
    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }
    
    public static boolean isPackageInstalled(Context context, String packageName) {
        try {
            context.getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
    
    public static String findInstalledApp(Context context, String query) {
        if (query == null || query.isEmpty()) return null;
        
        try {
            PackageManager pm = context.getPackageManager();
            Intent intent = new Intent(Intent.ACTION_MAIN, null);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            java.util.List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(intent, 0);
            
            if (apps == null) return null;
            
            // First pass: exact match
            for (android.content.pm.ResolveInfo info : apps) {
                String label = info.loadLabel(pm).toString();
                if (label.equalsIgnoreCase(query)) {
                    return info.activityInfo.packageName;
                }
            }
            
            // Second pass: contains match
            for (android.content.pm.ResolveInfo info : apps) {
                String label = info.loadLabel(pm).toString();
                if (label.toLowerCase().contains(query.toLowerCase())) {
                    return info.activityInfo.packageName;
                }
            }
        } catch (Exception e) {
            // Silently fail
        }
        return null;
    }
}
