package com.trixai.assistant.service;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;

import com.trixai.assistant.R;
import com.trixai.assistant.TrixAIApp;
import com.trixai.assistant.ui.MainActivity;

public class TrixService extends Service {
    
    private static final String TAG = "TrixService";
    public static final String ACTION_START = "com.trixai.assistant.START";
    public static final String ACTION_STOP = "com.trixai.assistant.STOP";
    private static final int NOTIFICATION_ID = 1001;
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_START.equals(action)) {
                try {
                    startForeground(NOTIFICATION_ID, createNotification());
                } catch (Exception e) {
                    Log.e(TAG, "Failed to start foreground", e);
                    stopSelf();
                }
            } else if (ACTION_STOP.equals(action)) {
                stopForeground(true);
                stopSelf();
            }
        }
        return START_STICKY;
    }
    
    private Notification createNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_IMMUTABLE;
        PendingIntent openPending = PendingIntent.getActivity(this, 0, openIntent, flags);
        
        Intent stopIntent = new Intent(this, TrixService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 1, stopIntent, flags);
        
        return new NotificationCompat.Builder(this, TrixAIApp.CHANNEL_SERVICE)
            .setContentTitle("Trix AI is active")
            .setContentText("Tap to open Trix AI")
            .setSmallIcon(R.drawable.ic_trix_logo)
            .setContentIntent(openPending)
            .addAction(R.drawable.ic_mic_white, "Open", openPending)
            .addAction(R.drawable.ic_back, "Stop", stopPending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build();
    }
}
