package com.trixai.assistant.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import com.trixai.assistant.util.Prefs;

public class BootReceiver extends BroadcastReceiver {
    
    private static final String TAG = "BootReceiver";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            try {
                Prefs prefs = new Prefs(context);
                if (prefs.isBackgroundServiceEnabled()) {
                    Intent serviceIntent = new Intent(context, TrixService.class);
                    serviceIntent.setAction(TrixService.ACTION_START);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(serviceIntent);
                    } else {
                        context.startService(serviceIntent);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Failed to start service on boot", e);
            }
        }
    }
}
