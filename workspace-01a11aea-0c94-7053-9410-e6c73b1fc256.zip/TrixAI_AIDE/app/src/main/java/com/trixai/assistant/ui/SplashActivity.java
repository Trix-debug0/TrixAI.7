package com.trixai.assistant.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.trixai.assistant.R;
import com.trixai.assistant.util.Prefs;

public class SplashActivity extends AppCompatActivity {
    
    private boolean isFinishingNavigation = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        
        final TextView titleText = findViewById(R.id.splashTitle);
        final TextView taglineText = findViewById(R.id.splashTagline);
        final ImageView logoImage = findViewById(R.id.splashLogo);
        
        // Fade in animation
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(1200);
        fadeIn.setFillAfter(true);
        
        AlphaAnimation fadeInDelayed = new AlphaAnimation(0f, 1f);
        fadeInDelayed.setDuration(1200);
        fadeInDelayed.setStartOffset(400);
        fadeInDelayed.setFillAfter(true);
        
        logoImage.startAnimation(fadeIn);
        titleText.startAnimation(fadeIn);
        taglineText.startAnimation(fadeInDelayed);
        
        // Navigate after delay
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isFinishingNavigation || isFinishing()) return;
                isFinishingNavigation = true;
                
                Prefs prefs = new Prefs(SplashActivity.this);
                Intent targetIntent;
                
                if (prefs.isFirstLaunch()) {
                    targetIntent = new Intent(SplashActivity.this, OnboardingActivity.class);
                } else {
                    targetIntent = new Intent(SplashActivity.this, MainActivity.class);
                }
                
                startActivity(targetIntent);
                finish();
            }
        }, 2500);
    }
}
