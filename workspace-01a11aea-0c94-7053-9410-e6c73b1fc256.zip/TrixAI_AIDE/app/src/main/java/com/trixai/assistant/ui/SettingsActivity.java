package com.trixai.assistant.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.trixai.assistant.R;
import com.trixai.assistant.util.Prefs;

public class SettingsActivity extends AppCompatActivity {
    
    private Prefs prefs;
    
    // Assistant
    private Spinner voiceLanguageSpinner;
    private Switch wakeWordSwitch;
    
    // Activation
    private Switch overlaySwitch;
    
    // Accessibility
    private Switch hapticSwitch;
    private Switch speechSwitch;
    
    private boolean isLoadingSettings = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        
        prefs = new Prefs(this);
        initViews();
        isLoadingSettings = true;
        loadSettings();
        isLoadingSettings = false;
        setupListeners();
    }
    
    private void initViews() {
        voiceLanguageSpinner = findViewById(R.id.voiceLanguageSpinner);
        wakeWordSwitch = findViewById(R.id.wakeWordSwitch);
        overlaySwitch = findViewById(R.id.overlaySwitch);
        hapticSwitch = findViewById(R.id.hapticSwitch);
        speechSwitch = findViewById(R.id.speechSwitch);
    }
    
    private void loadSettings() {
        // Setup voice language spinner
        String[] languages = {"Auto Detect", "English", "Hindi", "Urdu"};
        ArrayAdapter<String> langAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, languages);
        voiceLanguageSpinner.setAdapter(langAdapter);
        
        String currentLang = prefs.getVoiceLanguage();
        int langPos = 0;
        if ("english".equals(currentLang)) langPos = 1;
        else if ("hindi".equals(currentLang)) langPos = 2;
        else if ("urdu".equals(currentLang)) langPos = 3;
        voiceLanguageSpinner.setSelection(langPos);
        
        // Load switches
        wakeWordSwitch.setChecked(prefs.isWakeWordEnabled());
        overlaySwitch.setChecked(prefs.isOverlayEnabled());
        hapticSwitch.setChecked(prefs.isHapticEnabled());
        speechSwitch.setChecked(prefs.isSpeechEnabled());
    }
    
    private void setupListeners() {
        // Back button
        ImageView backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        
        // Voice Language
        voiceLanguageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String[] codes = {"auto", "english", "hindi", "urdu"};
                prefs.setVoiceLanguage(codes[position]);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        
        // Wake Word
        wakeWordSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                if (!isLoadingSettings) prefs.setWakeWordEnabled(isChecked);
            }
        });
        
        // Overlay
        overlaySwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                if (isLoadingSettings) return;
                if (isChecked) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(SettingsActivity.this)) {
                        overlaySwitch.setChecked(false);
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                        return;
                    }
                    prefs.setOverlayEnabled(true);
                } else {
                    prefs.setOverlayEnabled(false);
                }
            }
        });
        
        // Haptic
        hapticSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                if (!isLoadingSettings) prefs.setHapticEnabled(isChecked);
            }
        });
        
        // Speech
        speechSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                if (!isLoadingSettings) prefs.setSpeechEnabled(isChecked);
            }
        });
        
        // Permission items
        findViewById(R.id.micPermissionRow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermission(Manifest.permission.RECORD_AUDIO, 300);
            }
        });
        
        findViewById(R.id.contactPermissionRow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermission(Manifest.permission.READ_CONTACTS, 302);
            }
        });
        
        findViewById(R.id.phonePermissionRow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermission(Manifest.permission.CALL_PHONE, 303);
            }
        });
        
        findViewById(R.id.smsPermissionRow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(SettingsActivity.this, 
                    new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS}, 304);
            }
        });
    }
    
    private void requestPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{permission}, requestCode);
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatus();
    }
    
    private void updatePermissionStatus() {
        updatePermissionRow(R.id.micPermissionStatus, Manifest.permission.RECORD_AUDIO);
        updatePermissionRow(R.id.contactPermissionStatus, Manifest.permission.READ_CONTACTS);
        updatePermissionRow(R.id.phonePermissionStatus, Manifest.permission.CALL_PHONE);
        updatePermissionRow(R.id.smsPermissionStatus, Manifest.permission.SEND_SMS);
    }
    
    private void updatePermissionRow(int viewId, String permission) {
        TextView statusText = findViewById(viewId);
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            statusText.setText("Granted");
        } else {
            statusText.setText("Not granted — Tap to enable");
        }
    }
}
