package com.trixai.assistant.util;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    private static final String PREFS_NAME = "trix_ai_prefs";
    private SharedPreferences prefs;
    
    public Prefs(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
    
    public boolean isFirstLaunch() {
        return prefs.getBoolean("first_launch", true);
    }
    
    public void setFirstLaunch(boolean first) {
        prefs.edit().putBoolean("first_launch", first).apply();
    }
    
    public String getVoiceLanguage() {
        try {
            return prefs.getString("voice_language", "auto");
        } catch (ClassCastException e) {
            return "auto";
        }
    }
    
    public void setVoiceLanguage(String lang) {
        prefs.edit().putString("voice_language", lang).apply();
    }
    
    public boolean isWakeWordEnabled() {
        return prefs.getBoolean("wake_word", false);
    }
    
    public void setWakeWordEnabled(boolean enabled) {
        prefs.edit().putBoolean("wake_word", enabled).apply();
    }
    
    public boolean isOverlayEnabled() {
        return prefs.getBoolean("overlay", false);
    }
    
    public void setOverlayEnabled(boolean enabled) {
        prefs.edit().putBoolean("overlay", enabled).apply();
    }
    
    public boolean isHapticEnabled() {
        return prefs.getBoolean("haptic", true);
    }
    
    public void setHapticEnabled(boolean enabled) {
        prefs.edit().putBoolean("haptic", enabled).apply();
    }
    
    public boolean isSpeechEnabled() {
        return prefs.getBoolean("speech", true);
    }
    
    public void setSpeechEnabled(boolean enabled) {
        prefs.edit().putBoolean("speech", enabled).apply();
    }
    
    public boolean isBackgroundServiceEnabled() {
        return prefs.getBoolean("background_service", true);
    }
    
    public void setBackgroundServiceEnabled(boolean enabled) {
        prefs.edit().putBoolean("background_service", enabled).apply();
    }
    
    public String getConfirmationLevel() {
        try {
            return prefs.getString("confirmation", "smart");
        } catch (ClassCastException e) {
            return "smart";
        }
    }
    
    public void setConfirmationLevel(String level) {
        prefs.edit().putString("confirmation", level).apply();
    }
}
