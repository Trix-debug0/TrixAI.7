package com.trixai.assistant;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.util.Log;

public class TrixAIApp extends Application {
    
    public static final String CHANNEL_SERVICE = "trix_service";
    public static final String CHANNEL_ACTIONS = "trix_actions";
    
    private static TrixAIApp instance;
    
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        createNotificationChannels();
    }
    
    public static TrixAIApp getInstance() {
        return instance;
    }
    
    private void createNotificationChannels() {
        try {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager == null) return;
            
            NotificationChannel serviceChannel = new NotificationChannel(
                CHANNEL_SERVICE,
                "Trix AI Service",
                NotificationManager.IMPORTANCE_LOW
            );
            serviceChannel.setDescription("Keeps Trix AI running");
            serviceChannel.setShowBadge(false);
            
            NotificationChannel actionChannel = new NotificationChannel(
                CHANNEL_ACTIONS,
                "Trix AI Actions",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            actionChannel.setDescription("Action notifications from Trix AI");
            
            manager.createNotificationChannel(serviceChannel);
            manager.createNotificationChannel(actionChannel);
        } catch (Exception e) {
            Log.e("TrixAIApp", "Failed to create notification channels", e);
        }
    }
}
