package com.trixai.assistant.actions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses natural language commands into structured intents.
 * Supports English, Hindi (Roman script/Hinglish), and Urdu.
 */
public class IntentParser {
    
    public static final int INTENT_UNKNOWN = 0;
    public static final int INTENT_OPEN_APP = 1;
    public static final int INTENT_CALL_CONTACT = 2;
    public static final int INTENT_CALL_NUMBER = 3;
    public static final int INTENT_SEND_WHATSAPP = 4;
    public static final int INTENT_SEND_SMS = 5;
    public static final int INTENT_READ_SCREEN = 6;
    public static final int INTENT_GO_BACK = 7;
    public static final int INTENT_GO_HOME = 8;
    public static final int INTENT_SCROLL = 9;
    public static final int INTENT_SEARCH_YOUTUBE = 10;
    public static final int INTENT_SEARCH_WEB = 11;
    public static final int INTENT_SET_ALARM = 12;
    public static final int INTENT_SET_TIMER = 13;
    public static final int INTENT_GET_BATTERY = 14;
    public static final int INTENT_GET_TIME = 15;
    public static final int INTENT_GET_DATE = 16;
    public static final int INTENT_FLASHLIGHT_ON = 17;
    public static final int INTENT_FLASHLIGHT_OFF = 18;
    public static final int INTENT_VOLUME_UP = 19;
    public static final int INTENT_VOLUME_DOWN = 20;
    public static final int INTENT_NAVIGATE = 21;
    public static final int INTENT_READ_NOTIFICATIONS = 22;
    public static final int INTENT_OPEN_SETTINGS = 23;
    public static final int INTENT_PLAY_MEDIA = 24;
    public static final int INTENT_PAUSE_MEDIA = 25;
    public static final int INTENT_NEXT_MEDIA = 26;
    public static final int INTENT_READ_SMS = 27;
    public static final int INTENT_GET_STORAGE = 28;
    public static final int INTENT_GENERAL_AI = 99;
    
    // Confirmation-required intents
    public static boolean requiresConfirmation(int intent) {
        return intent == INTENT_SEND_SMS || intent == INTENT_SEND_WHATSAPP || 
               intent == INTENT_CALL_NUMBER;
    }
    
    public static ParsedCommand parse(String text) {
        ParsedCommand cmd = new ParsedCommand();
        cmd.rawText = text;
        String lower = text.trim().toLowerCase();
        
        // Flashlight
        if (matchesAny(lower, "flashlight on", "torch on", "turn on flashlight", "torch jala", "torch on karo")) {
            cmd.intent = INTENT_FLASHLIGHT_ON;
            return cmd;
        }
        if (matchesAny(lower, "flashlight off", "torch off", "turn off flashlight", "torch bujha", "torch off karo")) {
            cmd.intent = INTENT_FLASHLIGHT_OFF;
            return cmd;
        }
        
        // Storage
        if (matchesAny(lower, "how much storage", "storage space", "free space", "available space", 
                "kitni jagah", "storage left", "memory left", "phone storage", "device storage")) {
            cmd.intent = INTENT_GET_STORAGE;
            return cmd;
        }
        
        // Battery
        if (matchesAny(lower, "how much battery", "kitna charge", "battery kitni", 
                "battery level", "battery percentage", "battery status") 
            && !matchesAny(lower, "open battery", "battery settings")) {
            cmd.intent = INTENT_GET_BATTERY;
            return cmd;
        }
        // Catch-all for "battery" only if it seems like a question
        if (lower.contains("battery") && (lower.contains("what") || lower.contains("how") || 
            lower.contains("much") || lower.contains("kitna") || lower.contains("kitni") ||
            lower.contains("check") || lower.equals("battery"))) {
            cmd.intent = INTENT_GET_BATTERY;
            return cmd;
        }
        
        // Time
        if (matchesAny(lower, "what time", "kitne baje", "time kya", "current time")) {
            cmd.intent = INTENT_GET_TIME;
            return cmd;
        }
        
        // Date
        if (matchesAny(lower, "what date", "today date", "aaj kaun", "what day")) {
            cmd.intent = INTENT_GET_DATE;
            return cmd;
        }
        
        // Volume
        if (matchesAny(lower, "volume up", "volume badhao", "increase volume", "volume tez", "louder")) {
            cmd.intent = INTENT_VOLUME_UP;
            return cmd;
        }
        if (matchesAny(lower, "volume down", "volume kam", "decrease volume", "volume dheere", "quieter")) {
            cmd.intent = INTENT_VOLUME_DOWN;
            return cmd;
        }
        
        // YouTube
        if (matchesAny(lower, "youtube search", "search youtube", "youtube pe search", "search on youtube")) {
            cmd.intent = INTENT_SEARCH_YOUTUBE;
            cmd.searchQuery = extractAfter(lower, text, new String[]{"search", "pe search", "on youtube", "youtube pe"});
            return cmd;
        }
        
        // Navigation
        if (matchesAny(lower, "navigate", "take me", "directions to", "rasta dikhao", "mujhe le chalo", "find nearest")) {
            cmd.intent = INTENT_NAVIGATE;
            cmd.location = extractAfter(lower, text, new String[]{"to", "towards", "nearest", "le chalo", "dikhao"});
            return cmd;
        }
        
        // Alarm
        if (matchesAny(lower, "set alarm", "alarm laga", "alarm set", "wake me")) {
            cmd.intent = INTENT_SET_ALARM;
            cmd.time = extractTime(text);
            return cmd;
        }
        
        // Timer
        if (matchesAny(lower, "set timer", "timer laga", "timer for", "timer set")) {
            cmd.intent = INTENT_SET_TIMER;
            cmd.time = extractTime(text);
            return cmd;
        }
        
        // Media
        if (matchesAny(lower, "next song", "next video", "agla", "skip")) {
            cmd.intent = INTENT_NEXT_MEDIA;
            return cmd;
        }
        if (matchesAny(lower, "pause", "ruk", "rok do")) {
            cmd.intent = INTENT_PAUSE_MEDIA;
            return cmd;
        }
        if (matchesAny(lower, "play music", "play song", "baja", "play media", "start music") 
            || lower.equals("play")) {
            cmd.intent = INTENT_PLAY_MEDIA;
            return cmd;
        }
        
        // Go back / home
        if (matchesAny(lower, "go back", "wapas", "peechhe jao")) {
            cmd.intent = INTENT_GO_BACK;
            return cmd;
        }
        if (lower.equals("back") || lower.startsWith("back ") || lower.endsWith(" back") 
            || lower.contains(" go back") || lower.contains(" wapas")) {
            cmd.intent = INTENT_GO_BACK;
            return cmd;
        }
        if (matchesAny(lower, "go home", "home screen", "home page", "ghar jao")) {
            cmd.intent = INTENT_GO_HOME;
            return cmd;
        }
        
        // Scroll
        if (matchesAny(lower, "scroll down", "scroll up", "niche jao", "upar jao", "scroll")) {
            cmd.intent = INTENT_SCROLL;
            cmd.scrollDirection = lower.contains("up") || lower.contains("upar") ? -1 : 1;
            return cmd;
        }
        
        // Read screen
        if (matchesAny(lower, "read screen", "read page", "what is on screen", "screen padho", "kya dikh raha")) {
            cmd.intent = INTENT_READ_SCREEN;
            return cmd;
        }
        
        // Notifications
        if (matchesAny(lower, "read notification", "notification padho", "notifications")) {
            cmd.intent = INTENT_READ_NOTIFICATIONS;
            return cmd;
        }
        
        // Settings
        if (matchesAny(lower, "open settings", "settings kholo", "go to settings")) {
            cmd.intent = INTENT_OPEN_SETTINGS;
            return cmd;
        }
        
        // Read SMS
        if (matchesAny(lower, "read sms", "read message", "sms padho", "latest sms", "latest message")) {
            cmd.intent = INTENT_READ_SMS;
            return cmd;
        }
        
        // WhatsApp
        if (matchesAny(lower, "whatsapp", "whats app")) {
            cmd.intent = INTENT_SEND_WHATSAPP;
            cmd.person = extractPerson(lower, text);
            cmd.message = extractMessage(lower, text);
            return cmd;
        }
        
        // SMS
        if (matchesAny(lower, "send sms", "send message", "sms bhejo", "text message", "message send")) {
            cmd.intent = INTENT_SEND_SMS;
            cmd.person = extractPerson(lower, text);
            cmd.phoneNumber = extractPhoneNumber(text);
            cmd.message = extractMessage(lower, text);
            return cmd;
        }
        
        // Call — must be more specific to avoid false positives like "call me tomorrow"
        if (matchesAny(lower, "phone laga", "call karo", "phone karo") && !lower.contains("whatsapp")) {
            String phone = extractPhoneNumber(text);
            if (phone != null) {
                cmd.intent = INTENT_CALL_NUMBER;
                cmd.phoneNumber = phone;
            } else {
                cmd.intent = INTENT_CALL_CONTACT;
                cmd.person = extractPerson(lower, text);
            }
            return cmd;
        }
        // English "call" — require a name/number after it
        if ((lower.startsWith("call ") || lower.contains(" call ") || lower.contains("please call ")) 
            && !lower.contains("whatsapp")) {
            String phone = extractPhoneNumber(text);
            if (phone != null) {
                cmd.intent = INTENT_CALL_NUMBER;
                cmd.phoneNumber = phone;
                return cmd;
            } else {
                cmd.intent = INTENT_CALL_CONTACT;
                cmd.person = extractPerson(lower, text);
                if (cmd.person != null) return cmd;
            }
        }
        if (matchesAny(lower, "dial")) {
            String phone = extractPhoneNumber(text);
            if (phone != null) {
                cmd.intent = INTENT_CALL_NUMBER;
                cmd.phoneNumber = phone;
                return cmd;
            }
        }
        
        // Web search
        if (matchesAny(lower, "search for", "google", "search web", "dhundo", "search karo")) {
            cmd.intent = INTENT_SEARCH_WEB;
            cmd.searchQuery = extractAfter(lower, text, new String[]{"for", "search", "google", "dhundo", "karo"});
            return cmd;
        }
        
        // Open app
        if (matchesAny(lower, "open", "launch", "start", "chalu karo", "kholo")) {
            cmd.intent = INTENT_OPEN_APP;
            cmd.appName = extractAppName(lower, text);
            return cmd;
        }
        
        // Default: General AI
        cmd.intent = INTENT_GENERAL_AI;
        return cmd;
    }
    
    // ===== Helper Methods =====
    
    private static boolean matchesAny(String text, String... keywords) {
        for (String kw : keywords) {
            if (text.contains(kw.toLowerCase())) return true;
        }
        return false;
    }
    
    private static String extractPerson(String lower, String original) {
        String[] patterns = {
            "(?:call|message|whatsapp|sms|send|text|phone)\\s+(?:to\\s+)?(.+?)(?:\\s+and|\\s+saying|\\s+on|\\s+about|\\s+that|\\.?$)",
            "(?:for|to)\\s+(.+?)(?:\\s+and|\\s+saying|\\s+about|\\.?$)"
        };
        for (String p : patterns) {
            Matcher m = Pattern.compile(p, Pattern.CASE_INSENSITIVE).matcher(original);
            if (m.find()) {
                String person = m.group(1).trim();
                if (person.length() > 0 && person.length() < 50) {
                    // Remove common prefixes
                    person = person.replaceFirst("(?i)^(to|for)\\s+", "").trim();
                    if (person.length() > 0) return person;
                }
            }
        }
        return null;
    }
    
    private static String extractPhoneNumber(String text) {
        Pattern p = Pattern.compile("(\\+?[0-9][0-9\\s\\-()]{7,})");
        Matcher m = p.matcher(text);
        if (m.find()) {
            return m.group(1).replaceAll("[\\s\\-()]", "");
        }
        return null;
    }
    
    private static String extractMessage(String lower, String original) {
        String[] patterns = {
            "saying (.+?)(?:\\s*\\.?$)",
            "message saying (.+?)(?:\\s*\\.?$)",
            "that (.+?)(?:\\s*\\.?$)"
        };
        for (String p : patterns) {
            Matcher m = Pattern.compile(p, Pattern.CASE_INSENSITIVE).matcher(original);
            if (m.find()) {
                String msg = m.group(1).trim();
                if (msg.length() > 0) return msg;
            }
        }
        return null;
    }
    
    private static String extractAppName(String lower, String original) {
        String[] patterns = {
            "open (.+?)(?:\\s+and|\\s*\\.?$)",
            "launch (.+?)(?:\\s+and|\\s*\\.?$)"
        };
        for (String p : patterns) {
            Matcher m = Pattern.compile(p, Pattern.CASE_INSENSITIVE).matcher(original);
            if (m.find()) {
                String name = m.group(1).trim();
                if (name.length() > 0) return name;
            }
        }
        return null;
    }
    
    private static String extractAfter(String lower, String original, String[] keywords) {
        for (String kw : keywords) {
            int idx = lower.indexOf(kw);
            if (idx >= 0) {
                String after = original.substring(idx + kw.length()).trim();
                if (after.length() > 0 && after.length() < 200) return after;
            }
        }
        return null;
    }
    
    private static String extractTime(String text) {
        Pattern p = Pattern.compile("(\\d{1,2}\\s*(?:am|pm|a\\.m\\.|p\\.m\\.))", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(text);
        if (m.find()) return m.group(1).trim();
        
        p = Pattern.compile("(\\d+)\\s*(?:minute|min|hour)", Pattern.CASE_INSENSITIVE);
        m = p.matcher(text);
        if (m.find()) return m.group(1).trim() + " " + (text.toLowerCase().contains("hour") ? "hours" : "minutes");
        
        return null;
    }
    
    // Parsed command result
    public static class ParsedCommand {
        public int intent = INTENT_UNKNOWN;
        public String rawText = "";
        public String person = null;
        public String phoneNumber = null;
        public String message = null;
        public String appName = null;
        public String searchQuery = null;
        public String time = null;
        public String location = null;
        public int scrollDirection = 1;
    }
}
