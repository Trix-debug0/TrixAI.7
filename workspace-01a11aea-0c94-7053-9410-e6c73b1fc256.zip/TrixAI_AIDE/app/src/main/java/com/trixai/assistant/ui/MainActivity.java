package com.trixai.assistant.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.trixai.assistant.R;
import com.trixai.assistant.actions.ActionExecutor;
import com.trixai.assistant.actions.IntentParser;
import com.trixai.assistant.service.TrixService;
import com.trixai.assistant.util.Prefs;
import com.trixai.assistant.voice.VoiceManager;

public class MainActivity extends AppCompatActivity implements 
    VoiceManager.OnVoiceListener, ActionExecutor.ActionCallback {
    
    private static final int REQUEST_MICROPHONE = 100;
    
    private ImageButton micButton;
    private ImageButton settingsButton;
    private TextView statusText;
    private TextView brandText;
    private TextView conversationText;
    private View statusIndicator;
    
    private VoiceManager voiceManager;
    private ActionExecutor actionExecutor;
    private Prefs prefs;
    private android.os.Handler mainHandler;
    
    private IntentParser.ParsedCommand pendingCommand;
    private boolean isVoiceReady = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        prefs = new Prefs(this);
        voiceManager = new VoiceManager(this);
        voiceManager.setOnVoiceListener(this);
        
        actionExecutor = new ActionExecutor(this);
        actionExecutor.setCallback(this);
        
        initViews();
        setupListeners();
        startForegroundService();
        
        // Delay voice trigger to let TTS initialize
        if (getIntent().getBooleanExtra("TRIGGER_VOICE", false)) {
            mainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    requestMicAndListen();
                }
            }, 500);
        }
    }
    
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("TRIGGER_VOICE", false)) {
            mainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    requestMicAndListen();
                }
            }, 300);
        }
    }
    
    private void initViews() {
        micButton = findViewById(R.id.micButton);
        settingsButton = findViewById(R.id.settingsButton);
        statusText = findViewById(R.id.statusText);
        brandText = findViewById(R.id.brandText);
        conversationText = findViewById(R.id.conversationText);
        statusIndicator = findViewById(R.id.statusIndicator);
    }
    
    private void setupListeners() {
        micButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performHaptic();
                
                if (pendingCommand != null) {
                    // Confirm pending action
                    actionExecutor.confirmAndExecute(pendingCommand);
                    pendingCommand = null;
                } else if (voiceManager.getCurrentState() == VoiceManager.STATE_LISTENING) {
                    voiceManager.stopListening();
                } else {
                    requestMicAndListen();
                }
            }
        });
        
        micButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                performHaptic();
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                return true;
            }
        });
        
        // Settings button click listener
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performHaptic();
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        
        settingsButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                performHaptic();
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                return true;
            }
        });
    }
    
    private void requestMicAndListen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
            == PackageManager.PERMISSION_GRANTED) {
            String lang = prefs.getVoiceLanguage();
            voiceManager.startListening(lang);
        } else {
            ActivityCompat.requestPermissions(this, 
                new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_MICROPHONE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                String lang = prefs.getVoiceLanguage();
                voiceManager.startListening(lang);
            } else {
                voiceManager.speak("Microphone permission is needed for voice commands.");
            }
        }
    }
    
    // ===== VoiceManager Callbacks =====
    
    @Override
    public void onStateChanged(int state) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                updateUIForState(state);
            }
        });
    }
    
    @Override
    public void onResult(String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                processCommand(text);
            }
        });
    }
    
    @Override
    public void onError(String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                statusText.setText(message);
                conversationText.setText(message);
                conversationText.setVisibility(View.VISIBLE);
                // Only speak if the error is NOT about TTS itself — avoids infinite loop
                if (message != null && !message.contains("not ready") && !message.contains("not available")) {
                    voiceManager.speak(message);
                }
            }
        });
    }
    
    @Override
    public void onPartialResult(String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                statusText.setText(text);
            }
        });
    }
    
    // ===== ActionExecutor Callbacks =====
    
    @Override
    public void onActionStarted(IntentParser.ParsedCommand cmd) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                statusText.setText("Working...");
            }
        });
    }
    
    @Override
    public void onActionCompleted(IntentParser.ParsedCommand cmd, String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (message != null && !message.isEmpty()) {
                    statusText.setText("Done");
                    conversationText.setText(message);
                    conversationText.setVisibility(View.VISIBLE);
                    voiceManager.speak(message);
                }
                resetToReady();
            }
        });
    }
    
    @Override
    public void onActionFailed(IntentParser.ParsedCommand cmd, String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                statusText.setText(message);
                conversationText.setText(message);
                conversationText.setVisibility(View.VISIBLE);
                voiceManager.speak(message);
                resetToReady();
            }
        });
    }
    
    @Override
    public void onConfirmationRequired(IntentParser.ParsedCommand cmd, String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                pendingCommand = cmd;
                statusText.setText("Waiting for confirmation");
                conversationText.setText(message);
                conversationText.setVisibility(View.VISIBLE);
                voiceManager.speak(message);
            }
        });
    }
    
    // ===== Processing =====
    
    private void processCommand(String text) {
        conversationText.setText(text);
        conversationText.setVisibility(View.VISIBLE);
        
        // Check for wake word
        String lower = text.toLowerCase().trim();
        if (lower.contains("hey trix") || lower.contains("hey tricks") || lower.equals("trix")) {
            voiceManager.speak("I'm listening.");
            mainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    requestMicAndListen();
                }
            }, 1000);
            return;
        }
        
        // Check for yes/no responses
        if (pendingCommand != null) {
            if (lower.contains("yes") || lower.contains("haan") || lower.contains("ha") || lower.contains("ji")) {
                actionExecutor.confirmAndExecute(pendingCommand);
                pendingCommand = null;
                return;
            }
            if (lower.contains("no") || lower.contains("nahi") || lower.contains("cancel")) {
                voiceManager.speak("Action cancelled.");
                pendingCommand = null;
                resetToReady();
                return;
            }
        }
        
        // Parse and execute
        IntentParser.ParsedCommand cmd = IntentParser.parse(text);
        statusText.setText("Thinking...");
        
        if (cmd.intent == IntentParser.INTENT_GENERAL_AI) {
            String response = getAIResponse(text);
            voiceManager.speak(response);
            conversationText.setText(response);
            conversationText.setVisibility(View.VISIBLE);
            resetToReady();
        } else {
            actionExecutor.execute(cmd);
        }
    }
    
    private String getAIResponse(String input) {
        String lower = input.toLowerCase();
        if (lower.contains("hello") || lower.contains("hi") || lower.contains("namaste")) {
            return "Hello! I'm Trix AI. How can I help you?";
        }
        if (lower.contains("thank")) {
            return "You're welcome! Anything else I can help with?";
        }
        return "I'm currently in offline mode. For advanced AI features, please check your internet connection.";
    }
    
    // ===== UI Updates =====
    
    private void updateUIForState(int state) {
        switch (state) {
            case VoiceManager.STATE_IDLE:
                micButton.setImageResource(R.drawable.ic_mic_black);
                micButton.setEnabled(true);
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_ready);
                statusText.setText("Tap to speak");
                brandText.setText("Trix AI");
                break;
            case VoiceManager.STATE_LISTENING:
                micButton.setImageResource(R.drawable.ic_mic_black);
                micButton.setEnabled(true);
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_listening);
                statusText.setText("Listening...");
                animateListening();
                break;
            case VoiceManager.STATE_PROCESSING:
                micButton.setImageResource(R.drawable.ic_mic_black);
                micButton.setEnabled(false);
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_processing);
                statusText.setText("Thinking...");
                break;
            case VoiceManager.STATE_SPEAKING:
                micButton.setImageResource(R.drawable.ic_speaker);
                micButton.setEnabled(true);
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_speaking);
                break;
        }
    }
    
    private void animateListening() {
        micButton.animate()
            .scaleX(1.1f)
            .scaleY(1.1f)
            .setDuration(500)
            .withEndAction(new Runnable() {
                @Override
                public void run() {
                    micButton.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(500)
                        .start();
                }
            })
            .start();
    }
    
    private void resetToReady() {
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                statusText.setText("Tap to speak");
                statusIndicator.setBackgroundResource(R.drawable.status_indicator_ready);
                micButton.setImageResource(R.drawable.ic_mic_black);
                micButton.setEnabled(true);
                brandText.setText("Trix AI");
            }
        }, 2000);
    }
    
    private void performHaptic() {
        if (prefs.isHapticEnabled()) {
            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(50);
                }
            }
        }
    }
    
    private void startForegroundService() {
        if (prefs.isBackgroundServiceEnabled()) {
            Intent intent = new Intent(this, TrixService.class);
            intent.setAction(TrixService.ACTION_START);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        // Refresh state when returning from settings
        isVoiceReady = true;
        updateUIForState(voiceManager != null ? voiceManager.getCurrentState() : VoiceManager.STATE_IDLE);
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clear handler callbacks to prevent leaks
        if (mainHandler != null) {
            mainHandler.removeCallbacksAndMessages(null);
        }
        // Clear pending command
        pendingCommand = null;
        // Destroy voice manager
        if (voiceManager != null) {
            voiceManager.destroy();
            voiceManager = null;
        }
    }
}
