package com.trixai.assistant.voice;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Manages voice input (speech recognition) and output (TTS).
 * Supports English, Hindi, and Urdu.
 */
public class VoiceManager {
    
    private static final String TAG = "VoiceManager";
    
    public static final int STATE_IDLE = 0;
    public static final int STATE_LISTENING = 1;
    public static final int STATE_PROCESSING = 2;
    public static final int STATE_SPEAKING = 3;
    
    private Context context;
    private TextToSpeech tts;
    private SpeechRecognizer speechRecognizer;
    private boolean isTtsReady = false;
    private int currentState = STATE_IDLE;
    private Handler handler = new Handler(Looper.getMainLooper());
    
    // Callbacks
    private OnVoiceListener listener;
    
    public interface OnVoiceListener {
        void onStateChanged(int state);
        void onResult(String text);
        void onError(String message);
        void onPartialResult(String text);
    }
    
    public VoiceManager(Context context) {
        this.context = context;
        initTTS();
    }
    
    public void setOnVoiceListener(OnVoiceListener listener) {
        this.listener = listener;
    }
    
    private void initTTS() {
        tts = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    isTtsReady = true;
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override
                        public void onStart(String utteranceId) {}
                        
                        @Override
                        public void onDone(String utteranceId) {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    if (currentState == STATE_SPEAKING) {
                                        setState(STATE_IDLE);
                                    }
                                }
                            });
                        }
                        
                        @Override
                        public void onError(String utteranceId) {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    setState(STATE_IDLE);
                                }
                            });
                        }
                    });
                } else {
                    Log.e(TAG, "TTS initialization failed: " + status);
                }
            }
        });
    }
    
    public void speak(String text) {
        if (!isTtsReady || tts == null) {
            if (listener != null) listener.onError("Voice output not ready");
            return;
        }
        
        if (text == null || text.isEmpty()) return;
        
        setState(STATE_SPEAKING);
        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
        
        try {
            int result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "trix_response");
            if (result == TextToSpeech.ERROR) {
                setState(STATE_IDLE);
            }
        } catch (Exception e) {
            Log.e(TAG, "TTS speak error", e);
            setState(STATE_IDLE);
        }
    }
    
    public void startListening(String language) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            if (listener != null) listener.onError("Speech recognition not available on this device.");
            return;
        }
        
        setState(STATE_LISTENING);
        
        try {
            if (speechRecognizer != null) {
                speechRecognizer.cancel();
                speechRecognizer.destroy();
                speechRecognizer = null;
            }
            
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context);
            speechRecognizer.setRecognitionListener(createRecognitionListener());
            
            Intent intent = createRecognitionIntent(language);
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error starting speech recognition", e);
            setState(STATE_IDLE);
            if (listener != null) listener.onError("Could not start listening. Please try again.");
        }
    }
    
    public void stopListening() {
        try {
            if (speechRecognizer != null) {
                speechRecognizer.cancel();
                speechRecognizer.destroy();
                speechRecognizer = null;
            }
        } catch (Exception e) {
            Log.w(TAG, "Error stopping speech recognition", e);
        }
        setState(STATE_IDLE);
    }
    
    public void destroy() {
        isTtsReady = false;
        currentState = STATE_IDLE;
        
        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
                speechRecognizer.destroy();
            } catch (Exception e) {
                Log.w(TAG, "Error destroying speech recognizer", e);
            }
            speechRecognizer = null;
        }
        
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception e) {
                Log.w(TAG, "Error shutting down TTS", e);
            }
            tts = null;
        }
        
        handler.removeCallbacksAndMessages(null);
    }
    
    private RecognitionListener createRecognitionListener() {
        return new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                setState(STATE_LISTENING);
            }
            
            @Override
            public void onBeginningOfSpeech() {
                setState(STATE_LISTENING);
            }
            
            @Override
            public void onRmsChanged(float rmsdB) {}
            
            @Override
            public void onBufferReceived(byte[] buffer) {}
            
            @Override
            public void onEndOfSpeech() {
                setState(STATE_PROCESSING);
            }
            
            @Override
            public void onError(int error) {
                String errorMessage;
                switch (error) {
                    case SpeechRecognizer.ERROR_NO_MATCH:
                        errorMessage = "I didn't catch that. Please try again.";
                        break;
                    case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                        errorMessage = "I didn't hear anything. Please try again.";
                        break;
                    case SpeechRecognizer.ERROR_AUDIO:
                        errorMessage = "Audio recording error.";
                        break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                        errorMessage = "Microphone permission required.";
                        break;
                    case SpeechRecognizer.ERROR_NETWORK:
                        errorMessage = "Network error.";
                        break;
                    default:
                        errorMessage = "Speech recognition error.";
                }
                Log.e(TAG, "Recognition error: " + error);
                setState(STATE_IDLE);
                if (listener != null) listener.onError(errorMessage);
            }
            
            @Override
            public void onResults(Bundle results) {
                if (results == null) {
                    setState(STATE_IDLE);
                    if (listener != null) listener.onError("I couldn't understand that.");
                    return;
                }
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String text = matches.get(0);
                    if (text != null && !text.trim().isEmpty()) {
                        setState(STATE_PROCESSING);
                        if (listener != null) listener.onResult(text.trim());
                    } else {
                        setState(STATE_IDLE);
                        if (listener != null) listener.onError("I couldn't understand that.");
                    }
                } else {
                    setState(STATE_IDLE);
                    if (listener != null) listener.onError("I couldn't understand that.");
                }
            }
            
            @Override
            public void onPartialResults(Bundle partialResults) {
                if (partialResults == null) return;
                ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String text = matches.get(0);
                    if (text != null && !text.trim().isEmpty()) {
                        if (listener != null) listener.onPartialResult(text.trim());
                    }
                }
            }
            
            @Override
            public void onEvent(int eventType, Bundle params) {}
        };
    }
    
    private Intent createRecognitionIntent(String language) {
        Locale locale;
        switch (language) {
            case "hindi":
                locale = new Locale("hi", "IN");
                break;
            case "urdu":
                locale = new Locale("ur", "PK");
                break;
            default:
                locale = Locale.ENGLISH;
        }
        
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toLanguageTag());
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 3000L);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L);
        return intent;
    }
    
    private void setState(int state) {
        currentState = state;
        if (listener != null) listener.onStateChanged(state);
    }
    
    public int getCurrentState() {
        return currentState;
    }
}
