package com.trixai.assistant.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.trixai.assistant.R;
import com.trixai.assistant.util.Prefs;
import com.trixai.assistant.voice.VoiceManager;

public class OnboardingActivity extends AppCompatActivity {
    
    private static final int REQUEST_MICROPHONE = 200;
    private static final int REQUEST_OVERLAY = 202;
    
    private TextView titleText, descriptionText, pageIndicator;
    private ImageView iconImage;
    private Button nextButton, skipButton;
    
    private VoiceManager voiceManager;
    private Prefs prefs;
    private int currentStep = 0;
    
    private String[] titles = {
        "Welcome to Trix AI",
        "Microphone Permission",
        "Display Overlay",
        "You're All Set!"
    };
    
    private String[] descriptions = {
        "Your voice can control your phone. Let me guide you through the setup.",
        "I need microphone permission so I can hear your voice commands.",
        "Display overlay allows you to access Trix AI from other applications through a floating button.",
        "Trix AI is ready. You can say 'Hey Trix' or tap the microphone button to start."
    };
    
    private int[] icons = {
        R.drawable.ic_mic_white,
        R.drawable.ic_mic_white,
        R.drawable.ic_overlay,
        R.drawable.ic_check
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);
        
        prefs = new Prefs(this);
        voiceManager = new VoiceManager(this);
        
        initViews();
        setupListeners();
        updateStep();
        
        // Wait for TTS to initialize, then speak welcome message
        new android.os.Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                voiceManager.speak("Welcome to Trix AI. Let me guide you through the setup.");
            }
        }, 1500);
    }
    
    private void initViews() {
        titleText = findViewById(R.id.onboardingTitle);
        descriptionText = findViewById(R.id.onboardingDescription);
        iconImage = findViewById(R.id.onboardingIcon);
        nextButton = findViewById(R.id.nextButton);
        skipButton = findViewById(R.id.skipButton);
        pageIndicator = findViewById(R.id.pageIndicator);
    }
    
    private void setupListeners() {
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleStep();
            }
        });
        
        skipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                completeOnboarding();
            }
        });
    }
    
    private void handleStep() {
        switch (currentStep) {
            case 0: // Welcome - already spoken in onCreate, just advance
                moveToNext();
                break;
            case 1: // Microphone
                requestMicrophonePermission();
                break;
            case 2: // Overlay
                requestOverlayPermission();
                break;
            case 3: // Done
                completeOnboarding();
                break;
        }
    }
    
    private void requestMicrophonePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
            == PackageManager.PERMISSION_GRANTED) {
            voiceManager.speak("Microphone permission granted.");
            moveToNext();
        } else {
            ActivityCompat.requestPermissions(this, 
                new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
        }
    }
    
    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(this)) {
                voiceManager.speak("Display overlay is already enabled.");
                moveToNext();
            } else {
                voiceManager.speak("Please enable display overlay for Trix AI.");
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY);
            }
        } else {
            moveToNext();
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_MICROPHONE) {
            moveToNext();
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            // Check if overlay permission was actually granted
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                if (android.provider.Settings.canDrawOverlays(this)) {
                    voiceManager.speak("Display overlay enabled. Great!");
                } else {
                    voiceManager.speak("Display overlay not enabled. You can enable it later in settings.");
                }
            }
            moveToNext();
        }
    }
    
    private void moveToNext() {
        currentStep++;
        if (currentStep >= titles.length) {
            completeOnboarding();
        } else {
            updateStep();
        }
    }
    
    private void updateStep() {
        titleText.setText(titles[currentStep]);
        descriptionText.setText(descriptions[currentStep]);
        iconImage.setImageResource(icons[currentStep]);
        pageIndicator.setText((currentStep + 1) + " of " + titles.length);
        
        if (currentStep == titles.length - 1) {
            nextButton.setText("Get Started");
            skipButton.setVisibility(View.GONE);
        } else {
            nextButton.setText("Next");
            skipButton.setVisibility(View.VISIBLE);
        }
    }
    
    private void completeOnboarding() {
        prefs.setFirstLaunch(false);
        voiceManager.speak("Welcome to Trix AI. Your voice. Your phone. Your freedom.");
        
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (voiceManager != null) {
            voiceManager.destroy();
        }
    }
}
