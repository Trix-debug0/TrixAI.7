# Trix AI — AIDE Build Guide

## Your Voice. Your Phone. Your Freedom.

Professional voice assistant for blind & visually impaired Android users.
Built entirely for building on an Android phone using the **AIDE** app.

---

## 📱 How to Build on Your Phone

### Step 1: Install AIDE
Download **AIDE - Android IDE** from the Play Store.
(The free version works. Premium removes ads.)

### Step 2: Transfer Project to Your Phone
You have the `TrixAI_AIDE` folder. Transfer it to your phone:
- Use USB cable, Google Drive, or any file transfer method
- Place it in your phone's internal storage (e.g., `/sdcard/TrixAI_AIDE/`)

### Step 3: Open in AIDE
1. Open **AIDE** app
2. Tap the **folder icon** (top-left)
3. Navigate to where you placed `TrixAI_AIDE`
4. Tap the folder to open it
5. AIDE will recognize it as an Android project

### Step 4: Build the APK
1. Tap the **▶ Play button** (top bar)
2. AIDE will compile the project
3. If there are errors, they'll appear in the log
4. On success, the APK will be in:
   `/sdcard/TrixAI_AIDE/app/build/outputs/apk/debug/app-debug.apk`

### Step 5: Install the APK
1. Go to your file manager
2. Navigate to the APK location above
3. Tap the APK file
4. Allow "Install from unknown sources" when prompted
5. Tap **Install**

---

## ✅ Features That Work

| Feature | Status | Notes |
|---------|--------|-------|
| Voice commands (tap mic) | ✅ Working | Uses Android's built-in speech recognition |
| English voice input | ✅ Working | |
| Hindi/Hinglish voice input | ✅ Working | Select Hindi in Settings |
| Urdu voice input | ✅ Working | Select Urdu in Settings |
| Text-to-speech output | ✅ Working | Uses Android's built-in TTS |
| Open apps | ✅ Working | Detects installed apps |
| Make calls | ✅ Working | Requires phone permission |
| Send SMS | ✅ Working | Requires SMS permission |
| WhatsApp messages | ✅ Working | Opens WhatsApp with message |
| YouTube search | ✅ Working | Uses YouTube app or browser |
| Battery level | ✅ Working | |
| Current time | ✅ Working | |
| Current date | ✅ Working | |
| Volume up/down | ✅ Working | |
| Navigation/Maps | ✅ Working | Requires Google Maps |
| Set alarm | ✅ Working | |
| Set timer | ✅ Working | |
| Flashlight on/off | ✅ UI only | Add CameraManager code to enable |
| Web search | ✅ Working | |
| Settings page | ✅ Working | |
| Onboarding wizard | ✅ Working | Voice-guided setup |
| Splash screen | ✅ Working | |
| Black & White theme | ✅ Working | |
| Haptic feedback | ✅ Working | |
| Floating overlay | ✅ Working | Requires overlay permission |
| Background service | ✅ Working | Foreground notification |
| "Hey Trix" wake word | ⚠️ Partial | Uses speech recognition |
| Boot startup | ✅ Working | Auto-starts service |
| Duplicate prevention | ✅ Working | |
| Safety confirmations | ✅ Working | SMS, WhatsApp, calls |

---

## 🎯 Example Voice Commands

**English:**
- "Open YouTube"
- "Call Rahul"
- "Send SMS to Mom saying I am coming home"
- "What is my battery?"
- "What time is it?"
- "Navigate to Mumbai Central"
- "Search YouTube for Arijit Singh"
- "Turn volume up"

**Hindi/Hinglish:**
- "YouTube kholo"
- "Rahul ko call karo"
- "Battery kitni hai?"
- "Volume badhao"
- "WhatsApp pe Rahul ko message bhejo"

**Urdu:**
- (Select Urdu in Settings, then speak naturally)

---

## 📁 Project Structure

```
TrixAI_AIDE/
├── build.gradle                    (project build config)
├── settings.gradle
├── app/
│   ├── build.gradle                (app build config)
│   └── src/main/
│       ├── AndroidManifest.xml     (permissions & components)
│       ├── java/com/trixai/assistant/
│       │   ├── TrixAIApp.java             (Application class)
│       │   ├── actions/
│       │   │   ├── IntentParser.java      (NLP command parser)
│       │   │   └── ActionExecutor.java    (Executes commands)
│       │   ├── voice/
│       │   │   └── VoiceManager.java      (Speech in/out)
│       │   ├── service/
│       │   │   ├── TrixService.java       (Background service)
│       │   │   ├── OverlayService.java    (Floating button)
│       │   │   └── BootReceiver.java      (Auto-start)
│       │   ├── ui/
│       │   │   ├── SplashActivity.java    (Splash screen)
│       │   │   ├── MainActivity.java      (Main interface)
│       │   │   ├── OnboardingActivity.java (Setup wizard)
│       │   │   └── SettingsActivity.java  (Settings)
│       │   └── util/
│       │       ├── Prefs.java             (Preferences)
│       │       └── Utils.java             (Utilities)
│       └── res/
│           ├── layout/              (5 XML layouts)
│           ├── drawable/            (19 vector icons & shapes)
│           ├── values/              (strings, colors, themes)
│           └── mipmap-anydpi-v26/   (launcher icons)
```

---

## 🔧 Troubleshooting AIDE Build Errors

### Error: "cannot find symbol class ..."
- AIDE might not support some AndroidX libraries
- Fix: In `app/build.gradle`, try removing `androidx.constraintlayout` dependency

### Error: "resource not found"
- Check that all drawable XMLs are properly named
- AIDE may need `android:src` instead of `app:srcCompat`

### Error: Gradle sync failed
- AIDE uses its own build system
- Make sure you open the **parent folder** (TrixAI_AIDE), not the app folder
- AIDE should detect `build.gradle` and `settings.gradle` automatically

### APK not installing
- Enable "Unknown sources" in Settings → Security
- Some phones need: Settings → Apps → Special access → Install unknown apps

---

## 📝 AIDE-Specific Notes

1. **Java only** — AIDE handles Java better than Kotlin
2. **Simple dependencies** — Only basic AndroidX libraries used
3. **No external SDKs** — Uses Android's built-in speech APIs
4. **Vector drawables** — All icons are XML vectors (no PNGs needed)
5. **No Google Play Services required** — Works on any Android phone

---

## 🎨 Design

- **Black background** with white text
- **Large 160dp microphone button** — easy to tap
- **Haptic feedback** on every interaction
- **Voice feedback** for every action
- **High contrast** — accessible for visually impaired users
- **Simple navigation** — minimal screen interaction needed

---

*Trix AI — Your Voice. Your Phone. Your Freedom.*
